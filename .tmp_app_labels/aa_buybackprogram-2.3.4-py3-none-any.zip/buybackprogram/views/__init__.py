"""
Initialize the views
"""
