"""
App init
"""

# Django
from django.utils.translation import gettext_lazy as _

__version__ = "4.2.0"
__title__ = "Sovereignty Timer"
__title_translated__ = _("Sovereignty Timer")

__esi_compatibility_date__ = "2026-05-19"

__package_name__ = "aa-sov-timer"
__app_name__ = "sovtimer"
__app_name_verbose__ = "AA Sovereignty Timer"

__github_url__ = f"https://github.com/ppfeufer/{__package_name__}"
