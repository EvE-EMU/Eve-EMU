# Standard Library
import datetime
import functools
import inspect
from functools import wraps
from time import time
from typing import Any, Callable

# Third Party
from aiopenapi3.errors import RequestError as RequestError
from celery import Task, signature
from celery.exceptions import Retry
from celery_once import AlreadyQueued
from eve_sde.tasks import check_for_sde_updates
from httpx import RequestError as httpx_RequestError

# Django
from django.core.cache import cache
from django.db.models import QuerySet
from django.db.utils import IntegrityError
from django.utils import timezone

# Alliance Auth
from allianceauth.services.hooks import get_extension_logger
from esi.exceptions import (
    ESIBucketLimitException,
    HTTPClientError,
    HTTPServerError,
)

# AA Example App
from corptools.tasks.rate_limiting import (
    TaskBucketLimitException,
    TaskRateLimitBucket,
    rate_limiter,
    task_bucket_slug_key,
)

logger = get_extension_logger(__name__)


def enqueue_next_task(chain, delay=1):
    """
        Queue next task, and attach the rest of the chain to it.
    """
    while (len(chain)):
        _t = chain.pop(0)
        _t = signature(_t)
        _t.kwargs.update({"chain": chain})
        try:
            _t.apply_async(priority=6, countdown=delay)
        except AlreadyQueued:
            # skip this task as it is already in the queue
            logger.warning(f"Skipping task as its already queued {_t}")
            continue
        break


def set_error_flag(timeout):
    tout = timezone.now() + datetime.timedelta(seconds=timeout)
    cache.set("esi_error_timeout", tout, timeout=timeout + 1)


def get_error_flag():
    return cache.get("esi_error_timeout", default=timezone.now())


def clear_error_flag():
    cache.delete("esi_error_timeout")


def esi_error_retry(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        _ret = None

        if get_error_flag() >= timezone.now():
            logger.warning("Hit ESI error limit! will retry tasks!")
            args[0].retry(countdown=61)
        else:
            clear_error_flag()
        try:
            _ret = func(*args, **kwargs)
        except Exception as e:
            if isinstance(e, (ESIBucketLimitException)):  # OpenAPI
                logger.warning(f"Hit ESI rate bucket! Pausing Task! {e}")
                args[0].retry(countdown=e.reset)
            elif isinstance(e, (HTTPClientError, HTTPServerError)):  # OpenAPI
                code = e.status_code
                if code in (420, 429):
                    logger.warning(f"Hit ESI error limit! Pausing Tasks! {e}")
                    set_error_flag(60)
                    args[0].retry(countdown=61)
            elif isinstance(e, (RequestError, httpx_RequestError)):  # Generic Request Errors
                logger.warning(f"Uncaught RequestError, Retrying... {e}")
                args[0].retry(countdown=300)
            elif isinstance(e, (OSError)):  # Bravado
                logger.warning(f"Hit ESI error! Skipping task! {e}")
            elif isinstance(e, (IntegrityError)):
                logger.warning(
                    f"Hit DB Integrity Error! SDE not up to date? retrying in 15 minutes! {e}")
                check_for_sde_updates.apply_async(priority=1)
                if args[0].retires < 3:
                    sig = inspect.signature(func)

                    if "force_refresh" in sig.parameters:
                        args[0].retry(countdown=90, kwargs={
                                      "force_refresh": True})
                    else:
                        args[0].retry(countdown=90)
            raise e
        return _ret
    return wrapper


def no_fail_chain(func):
    """
        Decorator to chain tasks provided in the chain kwargs regardless of task failures.
        Be sure to add chain=[] to your kwargs. TODO make this not needed.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        excp = None
        _ret = None
        try:
            _ret = func(*args, **kwargs)
        except Exception as e:
            excp = e
        finally:
            _chn = kwargs.get("chain", [])
            if not isinstance(excp, Retry):
                enqueue_next_task(_chn)
            if excp:
                raise excp
        return _ret
    return wrapper


def chunks(lst, n):
    """Yield successive n-sized chunks from lst."""
    total = 0
    if isinstance(lst, list):
        total = len(lst)
    elif isinstance(lst, QuerySet):
        total = lst.count()

    for i in range(0, total, n):
        yield lst[i:i + n]


def rate_limited_task(rate: str, keys: list | None = None):
    """_summary_

    Args:
        rate (str): Max rate to run this task at, in the format of 100/15m or 10/s etc
        keys (list | bool, optional): optional keys to use for the pool. Otherwise uses task signature. Defaults to False.

    Returns:
        _type_: decorated func
    """
    def decorator_func(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            sig = inspect.signature(func)
            bound_args = sig.bind(*args, **kwargs)
            task: Task = bound_args.arguments["self"]
            key = task_bucket_slug_key(
                task.name,
                bound_args.arguments,
                restrict_to=keys
            )
            bucket = TaskRateLimitBucket.from_rate(key, rate)
            try:
                rate_limiter.check_bucket(bucket)
            except TaskBucketLimitException as ex:
                delay = ex.reset
                task.request.retries = task.request.retries - 1
                return task.retry(countdown=delay)
            else:
                return func(*args, **kwargs)
        return wrapper
    return decorator_func
