"""
Alliance Auth Crontab Utilities
"""
