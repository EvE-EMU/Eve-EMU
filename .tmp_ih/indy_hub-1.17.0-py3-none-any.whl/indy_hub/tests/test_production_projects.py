"""Tests for production project import parsing and resolution."""

# Standard Library
from types import SimpleNamespace
from unittest import TestCase
from unittest.mock import patch

# AA Example App
from indy_hub.models import generate_production_project_ref
from indy_hub.services.production_projects import (
    _build_project_blueprint_configs_grouped,
    _cached_payload_includes_blueprint_configs,
    _extract_workspace_me_te_overrides,
    _merge_me_te_overrides,
    _payload_uses_unpublished_blueprints,
    _remember_project_blueprint_for_product,
    _resolve_blueprints_for_products,
    _resolve_preferred_blueprint_for_product,
    aggregate_project_import_entries,
    build_project_import_preview,
    build_project_workspace_payload,
    normalize_production_project_ref,
    parse_project_import_text,
    resolve_project_import_entries,
)


class _PreviewCursorStub:
    def __init__(self):
        self._result = []
        self.last_query = ""
        self.last_params = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, sql, params=None):
        query = " ".join(str(sql).split())
        self.last_query = query
        self.last_params = params
        if "FROM eve_sde_itemtype" in query:
            self._result = [
                (1001, "Vedmak", "Cruiser"),
                (1002, "Thermal Armor Hardener II", "Armor Hardener"),
                (1003, "Warp Disruptor II", "Warp Disruptor"),
            ]
            return
        if "SELECT p.product_eve_type_id, p.eve_type_id, p.activity_id" in query:
            self._result = [
                (1001, 5001, 1),
                (1002, 5002, 1),
            ]
            return
        self._result = []

    def fetchone(self):
        return self._result[0] if self._result else None

    def fetchall(self):
        return self._result


class _FetchoneCursorStub:
    def __init__(self, fetchone_result=None):
        self._fetchone_result = fetchone_result
        self.last_query = ""
        self.last_params = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, sql, params=None):
        self.last_query = " ".join(str(sql).split())
        self.last_params = params

    def fetchone(self):
        return self._fetchone_result


class _ProjectItemsQueryStub:
    def __init__(self, items):
        self._items = items

    def filter(self, **kwargs):
        return self

    def exclude(self, **kwargs):
        return self

    def order_by(self, *fields):
        return list(self._items)


class _WorkspacePayloadCursorStub:
    product_rows = {
        1000: (2000, "Root Product", 1, 1, "Ships", 10),
        3001: (3000, "Child Product", 1, 1, "Modules", 11),
    }
    material_rows = {
        1000: [(3000, "Child Product", 10), (34, "Tritanium", 100)],
        3001: [],
    }

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, sql, params=None):
        query = " ".join(str(sql).split())
        blueprint_type_id = int((params or [0])[0] or 0)
        if "SELECT p.product_eve_type_id" in query:
            row = self.product_rows.get(blueprint_type_id)
            self._result = [row] if row else []
            return
        if "SELECT m.material_eve_type_id, COALESCE" in query:
            self._result = self.material_rows.get(blueprint_type_id, [])
            return
        if "SELECT m.material_eve_type_id, m.quantity" in query:
            self._result = [
                (type_id, quantity)
                for type_id, _name, quantity in self.material_rows.get(
                    blueprint_type_id, []
                )
            ]
            return
        if "SELECT t.meta_group_id_raw, g.category_id" in query:
            self._result = [(None, None)]
            return
        if "SELECT COALESCE(g.name, ''), g.id" in query:
            self._result = [("", None)]
            return
        self._result = []

    def fetchone(self):
        return self._result[0] if self._result else None

    def fetchall(self):
        return self._result


class ProductionProjectImportTests(TestCase):
    @patch(
        "indy_hub.models.secrets.choice",
        side_effect=list("a1b2c3d4e5"),
    )
    def test_generate_project_ref_returns_random_base36_token(
        self, mocked_choice
    ) -> None:
        project_ref = generate_production_project_ref()

        self.assertEqual(project_ref, "a1b2c3d4e5")
        self.assertEqual(len(project_ref), 10)
        self.assertEqual(mocked_choice.call_count, 10)

    def test_project_ref_rejects_invalid_tokens(self) -> None:
        with self.assertRaises(ValueError):
            normalize_production_project_ref("123")

        with self.assertRaises(ValueError):
            normalize_production_project_ref("00000000**")

    def test_project_ref_normalize_lowercases_valid_tokens(self) -> None:
        self.assertEqual(
            normalize_production_project_ref("ABC123DEF4"),
            "abc123def4",
        )

    def test_workspace_mete_overrides_ignore_legacy_zero_defaults(self) -> None:
        overrides = _extract_workspace_me_te_overrides(
            {
                "blueprint_efficiencies": [
                    {
                        "blueprint_type_id": 23916,
                        "material_efficiency": 0,
                        "time_efficiency": 0,
                    },
                    {
                        "blueprint_type_id": 23920,
                        "material_efficiency": 10,
                        "time_efficiency": 20,
                    },
                ]
            }
        )

        self.assertNotIn(23916, overrides)
        self.assertEqual(overrides[23920], {"me": 10, "te": 20})

    def test_workspace_mete_overrides_preserve_modern_zero_choices(self) -> None:
        overrides = _extract_workspace_me_te_overrides(
            {"meTeConfig": {"blueprintConfigs": {"23916": {"me": 0, "te": 0}}}}
        )

        self.assertEqual(overrides[23916], {"me": 0, "te": 0})

    def test_request_mete_overrides_replace_saved_workspace_choices(self) -> None:
        merged = _merge_me_te_overrides(
            {23916: {"me": 8, "te": 16}},
            {23916: {"me": 10}},
        )

        self.assertEqual(merged[23916], {"me": 10, "te": 16})

    def test_project_blueprint_cache_remembers_explicit_root_blueprint(self) -> None:
        product_blueprint_cache = {}

        _remember_project_blueprint_for_product(
            product_blueprint_cache,
            product_type_id=23915,
            blueprint_type_id=23916,
        )

        self.assertEqual(product_blueprint_cache, {23915: 23916})

    def test_cached_payload_requires_cards_for_used_blueprints(self) -> None:
        self.assertFalse(
            _cached_payload_includes_blueprint_configs(
                {
                    "materials_tree": [
                        {
                            "type_id": 23915,
                            "blueprint_type_id": 23916,
                            "sub_materials": [],
                        }
                    ],
                    "page": {"blueprint_configs": []},
                },
                {"blueprint_type_id": 23916},
            )
        )

    def test_cached_payload_allows_legacy_payload_without_page_configs(self) -> None:
        self.assertTrue(
            _cached_payload_includes_blueprint_configs(
                {
                    "materials_tree": [
                        {
                            "type_id": 23915,
                            "blueprint_type_id": 23916,
                            "sub_materials": [],
                        }
                    ]
                },
                {"blueprint_type_id": 23916},
            )
        )

    def test_cached_payload_accepts_cards_for_all_used_blueprints(self) -> None:
        self.assertTrue(
            _cached_payload_includes_blueprint_configs(
                {
                    "materials_tree": [
                        {
                            "type_id": 23915,
                            "blueprint_type_id": 23916,
                            "sub_materials": [
                                {
                                    "type_id": 123,
                                    "blueprint_type_id": 456,
                                    "sub_materials": [],
                                }
                            ],
                        }
                    ],
                    "page": {
                        "blueprint_configs": [
                            {"type_id": 23916},
                            {"type_id": 456},
                        ]
                    },
                },
                {"blueprint_type_id": 23916},
            )
        )

    def test_workspace_payload_resolves_user_blueprints_once_for_project_tree(
        self,
    ) -> None:
        project_item = SimpleNamespace(
            id=1,
            type_id=2000,
            type_name="Root Product",
            quantity_requested=1,
            is_selected=True,
            is_craftable=True,
            inclusion_mode="produce",
            blueprint_type_id=1000,
            category_key="manual",
            category_label="Manual list",
            category_order=90,
        )
        project = SimpleNamespace(
            id=1,
            project_ref="abc123def4",
            name="Root Project",
            status="draft",
            source_kind="manual",
            workspace_state={},
            notes="",
            user=object(),
            items=_ProjectItemsQueryStub([project_item]),
        )
        inventory_map = {
            1000: {
                "original": {"me": 0, "te": 0},
                "best_copy": {"me": 10, "te": 20},
                "copy_runs_total": 3,
            },
            3001: {
                "original": {"me": 8, "te": 16},
                "best_copy": None,
                "copy_runs_total": 0,
            },
        }

        with (
            patch(
                "indy_hub.services.production_projects.connection.cursor",
                side_effect=lambda: _WorkspacePayloadCursorStub(),
            ),
            patch(
                "indy_hub.services.production_projects._resolve_type_names",
                return_value={
                    34: "Tritanium",
                    1000: "Root Blueprint",
                    2000: "Root Product",
                    3000: "Child Product",
                    3001: "Child Blueprint",
                },
            ),
            patch(
                "indy_hub.services.production_projects._resolve_preferred_blueprint_for_product",
                side_effect=lambda type_id: {3000: 3001}.get(int(type_id)),
            ),
            patch(
                "indy_hub.services.production_projects._resolve_market_groups",
                return_value={},
            ),
            patch(
                "indy_hub.services.production_projects.is_base_item_material_efficiency_exempt",
                return_value=False,
            ),
            patch(
                "indy_hub.services.production_projects.build_craft_time_map",
                return_value={},
            ),
            patch(
                "indy_hub.services.production_projects.build_craft_character_advisor",
                return_value={"characters": [], "items": {}, "summary": {}},
            ),
            patch(
                "indy_hub.services.production_projects.build_craft_structure_planner",
                return_value={},
            ),
            patch(
                "indy_hub.services.production_projects._resolve_user_blueprint_inventory",
                return_value=inventory_map,
            ) as mock_inventory,
            patch(
                "indy_hub.services.production_projects._build_project_blueprint_configs_grouped",
                return_value=([], []),
            ) as mock_blueprint_configs,
        ):
            payload = build_project_workspace_payload(project)

        mock_inventory.assert_called_once()
        self.assertSetEqual(
            set(mock_inventory.call_args.kwargs["blueprint_type_ids"]),
            {1000, 3001},
        )
        self.assertEqual(payload["me"], 10)
        self.assertEqual(
            payload["materials_tree"][0]["sub_materials"][0]["blueprint_type_id"],
            3001,
        )
        self.assertIs(
            mock_blueprint_configs.call_args.kwargs["user_bp_map"],
            inventory_map,
        )

    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_use_best_copy_when_better_than_original(
        self,
        mock_inventory,
    ) -> None:
        mock_inventory.return_value = {
            46165: {
                "original": {"me": 0, "te": 0},
                "best_copy": {"me": 8, "te": 16},
                "copy_runs_total": 5,
            }
        }

        blueprints, _grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                78272: {
                    "type_id": 78272,
                    "type_name": "Cyclone Fleet Issue",
                    "total_needed": 2,
                }
            },
            product_blueprint_cache={78272: 46165},
            overrides={},
            type_name_cache={46165: "Cyclone Fleet Issue Blueprint"},
        )

        self.assertEqual(len(blueprints), 1)
        self.assertEqual(blueprints[0]["material_efficiency"], 8)
        self.assertEqual(blueprints[0]["time_efficiency"], 16)
        self.assertEqual(blueprints[0]["user_material_efficiency"], 8)
        self.assertEqual(blueprints[0]["user_time_efficiency"], 16)
        self.assertTrue(blueprints[0]["is_copy"])
        self.assertEqual(blueprints[0]["runs_available"], 5)

    @patch("indy_hub.services.production_projects.connection.cursor")
    def test_resolve_preferred_blueprint_for_product_prefers_published_types(
        self, mock_cursor
    ) -> None:
        cursor = _FetchoneCursorStub(fetchone_result=(46207,))
        mock_cursor.return_value = cursor

        resolved = _resolve_preferred_blueprint_for_product(16672)

        self.assertEqual(resolved, 46207)
        self.assertEqual(cursor.last_params, [16672])
        self.assertIn(
            "JOIN eve_sde_itemtype t ON t.id = p.eve_type_id", cursor.last_query
        )
        self.assertIn("COALESCE(t.published, 0) = 1", cursor.last_query)
        self.assertIn("COALESCE(product_t.published, 0) = 1", cursor.last_query)

    @patch(
        "indy_hub.services.production_projects.connection.cursor",
        return_value=_PreviewCursorStub(),
    )
    def test_resolve_blueprints_for_products_skips_unpublished_blueprints(
        self, _mock_cursor
    ) -> None:
        resolved = _resolve_blueprints_for_products([1001, 1002, 1003])

        self.assertEqual(resolved, {1001: 5001, 1002: 5002})

    @patch("indy_hub.services.production_projects.connection.cursor")
    def test_payload_uses_unpublished_blueprints_detects_cached_test_blueprints(
        self, mock_cursor
    ) -> None:
        cursor = _FetchoneCursorStub(fetchone_result=(45732,))
        mock_cursor.return_value = cursor

        payload = {
            "materials_tree": [
                {
                    "type_id": 16672,
                    "blueprint_type_id": 45732,
                    "sub_materials": [],
                }
            ]
        }

        self.assertTrue(_payload_uses_unpublished_blueprints(payload))
        self.assertEqual(cursor.last_params, [45732])
        self.assertIn("COALESCE(published, 0) = 0", cursor.last_query)

    def test_parse_eft_import_keeps_categories_and_quantities(self) -> None:
        payload = parse_project_import_text(
            """
[Vedmak, PVE - Vedmak Stronghold]

Thermal Armor Hardener II
Thermal Armor Hardener II

Warp Disruptor II x2
""".strip()
        )

        self.assertEqual(payload["source_kind"], "eft")
        self.assertEqual(payload["source_name"], "Vedmak // PVE - Vedmak Stronghold")
        self.assertEqual(payload["entries"][0]["type_name"], "Vedmak")
        self.assertEqual(payload["entries"][0]["category_key"], "hull")
        self.assertEqual(payload["entries"][1]["category_key"], "low_slots")
        self.assertEqual(payload["entries"][3]["category_key"], "mid_slots")
        self.assertEqual(payload["entries"][3]["quantity"], 2)

    def test_parse_eft_import_supports_brackets_in_fit_name(self) -> None:
        payload = parse_project_import_text(
            """
[Retribution,   [PRIME] SD 01]

Heat Sink II
""".strip()
        )

        self.assertEqual(payload["source_kind"], "eft")
        self.assertEqual(payload["source_name"], "Retribution // [PRIME] SD 01")
        self.assertEqual(payload["entries"][0]["type_name"], "Retribution")
        self.assertEqual(payload["entries"][0]["category_key"], "hull")

    def test_parse_manual_import_supports_prefix_and_suffix_quantities(self) -> None:
        payload = parse_project_import_text(
            """
3x Nanite Repair Paste
Vedmak x2
Auto Targeting System I
""".strip(),
            preferred_kind="manual",
        )

        self.assertEqual(payload["source_kind"], "manual")
        self.assertEqual(
            [entry["quantity"] for entry in payload["entries"]],
            [3, 2, 1],
        )
        self.assertTrue(
            all(entry["category_key"] == "manual" for entry in payload["entries"])
        )

    def test_aggregate_import_entries_merges_duplicates(self) -> None:
        aggregated = aggregate_project_import_entries(
            [
                {
                    "type_name": "Thermal Armor Hardener II",
                    "quantity": 1,
                    "category_key": "low_slots",
                    "category_label": "Low slots",
                    "category_order": 10,
                    "source_line": "Thermal Armor Hardener II",
                },
                {
                    "type_name": "Thermal Armor Hardener II",
                    "quantity": 2,
                    "category_key": "low_slots",
                    "category_label": "Low slots",
                    "category_order": 10,
                    "source_line": "Thermal Armor Hardener II x2",
                },
            ]
        )

        self.assertEqual(len(aggregated), 1)
        self.assertEqual(aggregated[0]["quantity"], 3)
        self.assertEqual(len(aggregated[0]["source_lines"]), 2)

    @patch(
        "indy_hub.services.production_projects.connection.cursor",
        return_value=_PreviewCursorStub(),
    )
    def test_resolve_entries_marks_craftable_and_non_craftable(
        self, _mock_cursor
    ) -> None:
        resolved = resolve_project_import_entries(
            [
                {
                    "type_name": "Vedmak",
                    "quantity": 1,
                    "category_key": "hull",
                    "category_label": "Hull",
                    "category_order": 0,
                    "source_line": "Vedmak",
                },
                {
                    "type_name": "Warp Disruptor II",
                    "quantity": 1,
                    "category_key": "mid_slots",
                    "category_label": "Mid slots",
                    "category_order": 20,
                    "source_line": "Warp Disruptor II",
                },
                {
                    "type_name": "Unknown Module",
                    "quantity": 1,
                    "category_key": "mid_slots",
                    "category_label": "Mid slots",
                    "category_order": 20,
                    "source_line": "Unknown Module",
                },
            ]
        )

        by_name = {entry["type_name"]: entry for entry in resolved}
        self.assertTrue(by_name["Vedmak"]["is_craftable"])
        self.assertEqual(by_name["Vedmak"]["blueprint_type_id"], 5001)
        self.assertFalse(by_name["Warp Disruptor II"]["is_craftable"])
        self.assertEqual(
            by_name["Warp Disruptor II"]["not_craftable_reason"], "no_blueprint"
        )
        self.assertFalse(by_name["Unknown Module"]["resolved"])
        self.assertEqual(
            by_name["Unknown Module"]["not_craftable_reason"], "unknown_item"
        )

    @patch(
        "indy_hub.services.production_projects.connection.cursor",
        return_value=_PreviewCursorStub(),
    )
    def test_build_preview_returns_grouped_summary(self, _mock_cursor) -> None:
        preview = build_project_import_preview(
            """
[Vedmak, Fleet]

Thermal Armor Hardener II
Warp Disruptor II
""".strip()
        )

        self.assertEqual(preview["summary"]["total_unique_items"], 3)
        self.assertEqual(preview["summary"]["craftable_items"], 2)
        self.assertEqual(preview["summary"]["non_craftable_items"], 1)
        self.assertEqual(preview["groups"][0]["key"], "hull")

    @patch("indy_hub.services.production_projects._resolve_blueprints_for_products")
    @patch("indy_hub.services.production_projects._resolve_item_types_by_name")
    def test_build_preview_reclassifies_drone_and_cargo_sections_without_subsystems(
        self,
        mock_resolve_items,
        mock_resolve_blueprints,
    ) -> None:
        mock_resolve_items.return_value = {
            "vedmak": {"type_id": 1, "type_name": "Vedmak", "group_name": "Cruiser"},
            "federation navy hammerhead": {
                "type_id": 2,
                "type_name": "Federation Navy Hammerhead",
                "group_name": "Medium Drone",
            },
            "tracking speed script": {
                "type_id": 3,
                "type_name": "Tracking Speed Script",
                "group_name": "Tracking Script",
            },
            "optimal range script": {
                "type_id": 4,
                "type_name": "Optimal Range Script",
                "group_name": "Tracking Script",
            },
            "tetryon exotic plasma m": {
                "type_id": 5,
                "type_name": "Tetryon Exotic Plasma M",
                "group_name": "Exotic Plasma Charge",
            },
            "meson exotic plasma m": {
                "type_id": 6,
                "type_name": "Meson Exotic Plasma M",
                "group_name": "Exotic Plasma Charge",
            },
            "warp disruptor ii": {
                "type_id": 7,
                "type_name": "Warp Disruptor II",
                "group_name": "Warp Scrambler",
            },
        }
        mock_resolve_blueprints.return_value = {
            1: 101,
            2: 102,
            3: 103,
            4: 104,
            5: 105,
            6: 106,
            7: 107,
        }

        preview = build_project_import_preview(
            """
[Vedmak,   PVE - Vedmak Stronghold ]

Thermal Armor Hardener II
EM Armor Hardener II
Entropic Radiation Sink II
Entropic Radiation Sink II
Entropic Radiation Sink II
Reactive Armor Hardener

F-12 Enduring Tracking Computer
Large Compact Pb-Acid Cap Battery
Large Compact Pb-Acid Cap Battery
10MN Afterburner II

Heavy Compact Entropic Disintegrator
Medium Coaxial Compact Remote Armor Repairer
Medium Coaxial Compact Remote Armor Repairer
Auto Targeting System I

Medium Ancillary Current Router I
Medium Capacitor Control Circuit I
Medium Polycarbon Engine Housing I




Federation Navy Hammerhead x7


Tracking Speed Script x1
Optimal Range Script x1
Tetryon Exotic Plasma M x10000
Meson Exotic Plasma M x2000
Warp Disruptor II x1
""".strip()
        )

        groups = {group["key"]: group for group in preview["groups"]}
        self.assertIn("drone_bay", groups)
        self.assertIn("cargo", groups)

        drone_items = {item["type_name"] for item in groups["drone_bay"]["items"]}
        cargo_items = {item["type_name"] for item in groups["cargo"]["items"]}

        self.assertEqual(drone_items, {"Federation Navy Hammerhead"})
        self.assertSetEqual(
            cargo_items,
            {
                "Tracking Speed Script",
                "Optimal Range Script",
                "Tetryon Exotic Plasma M",
                "Meson Exotic Plasma M",
                "Warp Disruptor II",
            },
        )

    @patch("indy_hub.services.production_projects._resolve_blueprints_for_products")
    @patch("indy_hub.services.production_projects._resolve_item_types_by_name")
    def test_build_preview_keeps_t3_subsystems_and_cargo_separate(
        self,
        mock_resolve_items,
        mock_resolve_blueprints,
    ) -> None:
        mock_resolve_items.return_value = {
            "legion": {
                "type_id": 10,
                "type_name": "Legion",
                "group_name": "Strategic Cruiser",
            },
            "legion defensive - augmented plating": {
                "type_id": 11,
                "type_name": "Legion Defensive - Augmented Plating",
                "group_name": "Defensive Systems",
            },
            "legion core - energy parasitic complex": {
                "type_id": 12,
                "type_name": "Legion Core - Energy Parasitic Complex",
                "group_name": "Core Systems",
            },
            "legion offensive - liquid crystal magnifiers": {
                "type_id": 13,
                "type_name": "Legion Offensive - Liquid Crystal Magnifiers",
                "group_name": "Offensive Systems",
            },
            "legion propulsion - intercalated nanofibers": {
                "type_id": 14,
                "type_name": "Legion Propulsion - Intercalated Nanofibers",
                "group_name": "Propulsion Systems",
            },
            "nanite repair paste": {
                "type_id": 15,
                "type_name": "Nanite Repair Paste",
                "group_name": "Nanite Repair Paste",
            },
            "scorch m": {
                "type_id": 16,
                "type_name": "Scorch M",
                "group_name": "Frequency Crystal",
            },
        }
        mock_resolve_blueprints.return_value = {
            10: 110,
            11: 111,
            12: 112,
            13: 113,
            14: 114,
            15: 115,
            16: 116,
        }

        preview = build_project_import_preview(
            """
[Legion, T3 test]

Thermal Armor Hardener II

50MN Microwarpdrive II

Heavy Pulse Laser II

Medium Auxiliary Nano Pump I

Legion Defensive - Augmented Plating
Legion Core - Energy Parasitic Complex
Legion Offensive - Liquid Crystal Magnifiers
Legion Propulsion - Intercalated Nanofibers

Nanite Repair Paste x200
Scorch M x1000
""".strip()
        )

        groups = {group["key"]: group for group in preview["groups"]}
        self.assertIn("subsystems", groups)
        self.assertIn("cargo", groups)

        subsystem_items = {item["type_name"] for item in groups["subsystems"]["items"]}
        cargo_items = {item["type_name"] for item in groups["cargo"]["items"]}

        self.assertSetEqual(
            subsystem_items,
            {
                "Legion Defensive - Augmented Plating",
                "Legion Core - Energy Parasitic Complex",
                "Legion Offensive - Liquid Crystal Magnifiers",
                "Legion Propulsion - Intercalated Nanofibers",
            },
        )
        self.assertSetEqual(cargo_items, {"Nanite Repair Paste", "Scorch M"})

    @patch("indy_hub.services.production_projects._resolve_blueprints_for_products")
    @patch("indy_hub.services.production_projects._resolve_item_types_by_name")
    def test_build_preview_keeps_tengu_fit_subsystems_and_spare_subsystem_separate(
        self,
        mock_resolve_items,
        mock_resolve_blueprints,
    ) -> None:
        mock_resolve_items.return_value = {
            "tengu": {
                "type_id": 20,
                "type_name": "Tengu",
                "group_name": "Strategic Cruiser",
            },
            "tengu core - augmented graviton reactor": {
                "type_id": 21,
                "type_name": "Tengu Core - Augmented Graviton Reactor",
                "group_name": "Core Systems",
            },
            "tengu defensive - covert reconfiguration": {
                "type_id": 22,
                "type_name": "Tengu Defensive - Covert Reconfiguration",
                "group_name": "Defensive Systems",
            },
            "tengu offensive - support processor": {
                "type_id": 23,
                "type_name": "Tengu Offensive - Support Processor",
                "group_name": "Offensive Systems",
            },
            "tengu propulsion - chassis optimization": {
                "type_id": 24,
                "type_name": "Tengu Propulsion - Chassis Optimization",
                "group_name": "Propulsion Systems",
            },
            "tengu defensive - supplemental screening": {
                "type_id": 25,
                "type_name": "Tengu Defensive - Supplemental Screening",
                "group_name": "Defensive Systems",
            },
            "warrior ii": {
                "type_id": 26,
                "type_name": "Warrior II",
                "group_name": "Light Scout Drone",
            },
            "acolyte ii": {
                "type_id": 27,
                "type_name": "Acolyte II",
                "group_name": "Light Scout Drone",
            },
        }
        mock_resolve_blueprints.return_value = {
            20: 120,
            21: 121,
            22: 122,
            23: 123,
            24: 124,
            25: 125,
            26: 126,
            27: 127,
        }

        preview = build_project_import_preview(
            """
[Tengu,  i.Dreamcatcher Boost]

Damage Control II
Power Diagnostic System II
Power Diagnostic System II

Multispectrum Shield Hardener II
Large Shield Extender II
50MN Quad LiF Restrained Microwarpdrive
Large Shield Extender II
EM Shield Hardener II
Large Shield Extender II

Covert Ops Cloaking Device II
Medium Asymmetric Enduring Remote Shield Booster
Medium Ancillary Remote Shield Booster
Shield Command Burst II
Shield Command Burst II
Shield Command Burst II
Information Command Burst II

Medium Command Processor I
Medium Command Processor I
Medium Core Defense Field Extender II

Tengu Core - Augmented Graviton Reactor
Tengu Defensive - Covert Reconfiguration
Tengu Offensive - Support Processor
Tengu Propulsion - Chassis Optimization





Warrior II x5
Acolyte II x5


Active Shielding Charge x300
Shield Harmonizing Charge x300
Shield Extension Charge x300
Sensor Optimization Charge x300
Electronic Superiority Charge x300
Electronic Hardening Charge x300
Evasive Maneuvers Charge x300
Interdiction Maneuvers Charge x300
Rapid Deployment Charge x300
Navy Cap Booster 50 x27
Nanite Repair Paste x100
Shield Command Mindlink x1
Information Command Burst II x2
Skirmish Command Burst II x3
Power Diagnostic System II x2
Tengu Defensive - Supplemental Screening x1
Interdiction Nullifier I x1
Mobile Depot x1
""".strip()
        )

        groups = {group["key"]: group for group in preview["groups"]}
        self.assertIn("subsystems", groups)
        self.assertIn("cargo", groups)
        self.assertIn("drone_bay", groups)

        subsystem_items = {item["type_name"] for item in groups["subsystems"]["items"]}
        cargo_items = {item["type_name"] for item in groups["cargo"]["items"]}
        drone_items = {item["type_name"] for item in groups["drone_bay"]["items"]}

        self.assertSetEqual(
            subsystem_items,
            {
                "Tengu Core - Augmented Graviton Reactor",
                "Tengu Defensive - Covert Reconfiguration",
                "Tengu Offensive - Support Processor",
                "Tengu Propulsion - Chassis Optimization",
            },
        )
        self.assertIn("Tengu Defensive - Supplemental Screening", cargo_items)
        self.assertFalse(subsystem_items & {"Tengu Defensive - Supplemental Screening"})
        self.assertSetEqual(drone_items, {"Warrior II", "Acolyte II"})

    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_use_user_owned_efficiencies_and_names(
        self,
        mock_inventory,
    ) -> None:
        mock_inventory.return_value = {
            46165: {
                "original": {"me": 10, "te": 20},
                "best_copy": None,
                "copy_runs_total": 0,
            }
        }

        blueprints, grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                78272: {
                    "type_id": 78272,
                    "type_name": "Cyclone Fleet Issue",
                    "total_needed": 2,
                }
            },
            product_blueprint_cache={78272: 46165},
            overrides={},
            type_name_cache={46165: "Cyclone Fleet Issue Blueprint"},
        )

        self.assertEqual(len(blueprints), 1)
        self.assertEqual(blueprints[0]["type_name"], "Cyclone Fleet Issue Blueprint")
        self.assertTrue(blueprints[0]["user_owns"])
        self.assertEqual(blueprints[0]["material_efficiency"], 10)
        self.assertEqual(blueprints[0]["time_efficiency"], 20)
        self.assertEqual(blueprints[0]["user_material_efficiency"], 10)
        self.assertEqual(blueprints[0]["user_time_efficiency"], 20)
        self.assertEqual(
            grouped[0]["levels"][0]["blueprints"][0]["type_name"],
            "Cyclone Fleet Issue Blueprint",
        )

    @patch("indy_hub.services.production_projects.is_reaction_blueprint")
    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_flag_reaction_blueprints(
        self,
        mock_inventory,
        mock_is_reaction,
    ) -> None:
        """Issue #69: reaction formulas are surfaced in the Blueprints tab so
        players can see which formulas the project consumes, but in a
        dedicated 'Reactions' group with no copy controls and ME/TE forced
        to 0."""

        mock_inventory.return_value = {}
        mock_is_reaction.return_value = True

        blueprints, grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                16670: {
                    "type_id": 16670,
                    "type_name": "Carbon Fiber",
                    "total_needed": 5,
                }
            },
            product_blueprint_cache={16670: 17887},
            overrides={16670: {"me": 8, "te": 14}},
            type_name_cache={17887: "Carbon Fiber Reaction Formula"},
        )

        self.assertEqual(len(blueprints), 1)
        card = blueprints[0]
        self.assertEqual(card["type_id"], 17887)
        self.assertTrue(card["is_reaction"])
        # ME/TE inputs are hidden in the template; values are forced to 0
        # even when an override exists.
        self.assertEqual(card["material_efficiency"], 0)
        self.assertEqual(card["time_efficiency"], 0)
        # No copy / shared-copy data so the card never enters the orange branch.
        self.assertEqual(card["shared_copies_available"], [])
        self.assertIsNone(card["runs_available"])
        # Reactions cannot be copied in EVE: the card must never claim the
        # owned blueprint is a copy (the template would otherwise render a
        # misleading "COPY OWNED" badge).
        self.assertFalse(card["is_copy"])
        # Dedicated 'Reactions' group, single level.
        self.assertEqual(len(grouped), 1)
        self.assertEqual(grouped[0]["group_name"], "Reactions")
        self.assertEqual(
            [bp["type_id"] for bp in grouped[0]["levels"][0]["blueprints"]],
            [17887],
        )
        mock_is_reaction.assert_called_with(17887)

    @patch("indy_hub.services.production_projects.is_reaction_blueprint")
    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_keep_non_reaction_when_mixed(
        self,
        mock_inventory,
        mock_is_reaction,
    ) -> None:
        """When a project mixes reaction and standard blueprints, the latter
        keep their normal category section and reactions land in the dedicated
        'Reactions' group rendered last."""

        mock_inventory.return_value = {}
        # 17887 (reaction formula) -> True, anything else -> False
        mock_is_reaction.side_effect = lambda type_id: int(type_id) == 17887

        blueprints, grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                16670: {
                    "type_id": 16670,
                    "type_name": "Carbon Fiber",
                    "total_needed": 5,
                },
                23919: {
                    "type_id": 23919,
                    "type_name": "Cyclone Fleet Issue",
                    "total_needed": 1,
                },
            },
            product_blueprint_cache={16670: 17887, 23919: 23920},
            overrides={},
            type_name_cache={
                17887: "Carbon Fiber Reaction Formula",
                23920: "Cyclone Fleet Issue Blueprint",
            },
            market_group_map={
                23919: {"group_name": "Battlecruiser", "group_id": 1},
                16670: {"group_name": "Composite Reaction", "group_id": 2},
            },
        )

        self.assertEqual(len(blueprints), 2)
        # Standard blueprint stays in its product category, reactions are
        # bucketed under 'Reactions' regardless of their product's category.
        self.assertEqual(
            [group["group_name"] for group in grouped],
            ["Battlecruiser", "Reactions"],
        )
        self.assertEqual(
            [bp["type_id"] for bp in grouped[0]["levels"][0]["blueprints"]],
            [23920],
        )
        self.assertEqual(
            [bp["type_id"] for bp in grouped[1]["levels"][0]["blueprints"]],
            [17887],
        )

    @patch("indy_hub.services.production_projects.is_reaction_blueprint")
    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_grouped_by_product_category(
        self,
        mock_inventory,
        mock_is_reaction,
    ) -> None:
        """Project Blueprints tab groups cards by product category so a project
        mixing ships, modules and ammo is easier to scan."""

        mock_inventory.return_value = {}
        mock_is_reaction.return_value = False

        blueprints, grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                23919: {
                    "type_id": 23919,
                    "type_name": "Cyclone Fleet Issue",
                    "total_needed": 1,
                },
                17738: {
                    "type_id": 17738,
                    "type_name": "Machariel",
                    "total_needed": 1,
                },
                2488: {
                    "type_id": 2488,
                    "type_name": "Warrior II",
                    "total_needed": 5,
                },
                34: {
                    "type_id": 34,
                    "type_name": "Tritanium",
                    "total_needed": 1000,
                },
            },
            product_blueprint_cache={
                23919: 23920,
                17738: 17739,
                2488: 2489,
                # No blueprint for Tritanium → ignored entirely
                34: None,
            },
            overrides={},
            type_name_cache={
                23920: "Cyclone Fleet Issue Blueprint",
                17739: "Machariel Blueprint",
                2489: "Warrior II Blueprint",
            },
            market_group_map={
                23919: {"group_name": "Battlecruiser", "group_id": 1},
                17738: {"group_name": "Battleship", "group_id": 2},
                2488: {"group_name": "Combat Drone", "group_id": 3},
            },
        )

        self.assertEqual(len(blueprints), 3)

        # One group per distinct category, sorted alphabetically.
        self.assertEqual(
            [group["group_name"] for group in grouped],
            ["Battlecruiser", "Battleship", "Combat Drone"],
        )
        # Each group contains a single level holding only its category's cards.
        battlecruiser = grouped[0]["levels"][0]["blueprints"]
        battleship = grouped[1]["levels"][0]["blueprints"]
        drones = grouped[2]["levels"][0]["blueprints"]
        self.assertEqual([bp["type_id"] for bp in battlecruiser], [23920])
        self.assertEqual([bp["type_id"] for bp in battleship], [17739])
        self.assertEqual([bp["type_id"] for bp in drones], [2489])
        for bp in battlecruiser:
            self.assertEqual(bp["category_name"], "Battlecruiser")

    @patch("indy_hub.services.production_projects.is_reaction_blueprint")
    @patch("indy_hub.services.production_projects._resolve_user_blueprint_inventory")
    def test_project_blueprint_configs_unknown_category_falls_back_to_other(
        self,
        mock_inventory,
        mock_is_reaction,
    ) -> None:
        """Cards whose product has no item-group entry land in the 'Other'
        bucket, which is always rendered last so named categories stay on top.
        """

        mock_inventory.return_value = {}
        mock_is_reaction.return_value = False

        blueprints, grouped = _build_project_blueprint_configs_grouped(
            user=object(),
            cycle_summary={
                23919: {
                    "type_id": 23919,
                    "type_name": "Cyclone Fleet Issue",
                    "total_needed": 1,
                },
                99999: {
                    "type_id": 99999,
                    "type_name": "Mystery Item",
                    "total_needed": 1,
                },
            },
            product_blueprint_cache={23919: 23920, 99999: 99998},
            overrides={},
            type_name_cache={
                23920: "Cyclone Fleet Issue Blueprint",
                99998: "Mystery Item Blueprint",
            },
            market_group_map={
                23919: {"group_name": "Battlecruiser", "group_id": 1},
                # 99999 deliberately missing → falls back to "Other"
            },
        )

        self.assertEqual(len(blueprints), 2)
        self.assertEqual(
            [group["group_name"] for group in grouped],
            ["Battlecruiser", "Other"],
        )
        self.assertEqual(
            [bp["type_id"] for bp in grouped[1]["levels"][0]["blueprints"]],
            [99998],
        )
