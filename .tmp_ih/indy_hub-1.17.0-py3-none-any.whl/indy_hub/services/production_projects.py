"""Helpers for multi-product production project imports and aggregation."""

from __future__ import annotations

# Standard Library
import hashlib
import json
import re
from collections import OrderedDict
from collections.abc import Iterable, Sequence
from copy import copy
from datetime import timedelta
from math import ceil
from time import perf_counter

# Django
from django.core.cache import cache
from django.db import connection

# Alliance Auth
from allianceauth.services.hooks import get_extension_logger

from ..models import (
    PROJECT_REF_BASE36_ALPHABET,
    PROJECT_REF_LENGTH,
    Blueprint,
    ProductionProject,
    ProductionProjectItem,
    SDESyncCompatState,
)
from ..utils.eve import (
    get_blueprint_product_type_id,
    get_type_name,
    is_reaction_blueprint,
)
from .craft_materials import (
    compute_job_material_quantity,
    is_base_item_material_efficiency_exempt,
)
from .craft_structures import build_craft_structure_planner
from .craft_times import build_craft_time_map
from .industry_skills import build_craft_character_advisor

logger = get_extension_logger(__name__)

EFT_HEADER_RE = re.compile(r"^\[(?P<hull>[^,\]]+?)\s*,\s*(?P<fit_name>.*?)\s*\]$")
QUANTITY_SUFFIX_RE = re.compile(r"^(?P<name>.+?)\s+x(?P<quantity>\d+)$", re.IGNORECASE)
QUANTITY_PREFIX_RE = re.compile(
    r"^(?P<quantity>\d+)\s*x?\s+(?P<name>.+)$", re.IGNORECASE
)
STRATEGIC_CRUISER_SUBSYSTEM_NAME_RE = re.compile(
    r"\b(?:legion|loki|proteus|tengu)\s+(?:defensive|offensive|core|propulsion)\b",
    re.IGNORECASE,
)
EFT_CATEGORY_SPECS: list[dict[str, object]] = [
    {"key": "low_slots", "label": "Low slots", "order": 10},
    {"key": "mid_slots", "label": "Mid slots", "order": 20},
    {"key": "high_slots", "label": "High slots", "order": 30},
    {"key": "rig_slots", "label": "Rig slots", "order": 40},
    {"key": "subsystems", "label": "Subsystems", "order": 50},
    {"key": "drone_bay", "label": "Drone bay", "order": 60},
    {"key": "cargo", "label": "Cargo", "order": 70},
]

MANUAL_CATEGORY = {"key": "manual", "label": "Manual list", "order": 90}
HULL_CATEGORY = {"key": "hull", "label": "Hull", "order": 0}
EFT_CATEGORY_SPEC_BY_KEY = {
    str(category["key"]): category for category in EFT_CATEGORY_SPECS
}
DRONE_GROUP_KEYWORDS = ("drone", "fighter", "fighter bomber")
SUBSYSTEM_GROUP_KEYWORDS = ("subsystem", "strategic cruiser")
PROJECT_WORKSPACE_PAYLOAD_CACHE_KEY = "cachedProjectPayload"
PROJECT_WORKSPACE_SDE_SIGNATURE_KEY = "cachedProjectSdeSignature"
PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_KEY = "cachedProjectScopedSdeSignature"
PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_VERSION = 1
PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_ID_LIMIT = 5000
PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_QUERY_CHUNK_SIZE = 500
PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_CACHE_TIMEOUT_SECONDS = 60 * 60 * 6
LEGACY_SINGLE_BLUEPRINT_PROJECT_NOTE = (
    "Migrated from legacy single-blueprint craft flow."
)


def strip_project_workspace_cache(
    workspace_state: dict[str, object] | None,
) -> dict[str, object]:
    cleaned_state = dict(workspace_state or {})
    cleaned_state.pop(PROJECT_WORKSPACE_PAYLOAD_CACHE_KEY, None)
    cleaned_state.pop(PROJECT_WORKSPACE_SDE_SIGNATURE_KEY, None)
    cleaned_state.pop(PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_KEY, None)
    cleaned_state.pop("pendingWorkspaceRefresh", None)
    cleaned_state.pop("pendingWorkspaceSourceTab", None)
    return cleaned_state


def get_project_workspace_sde_signature() -> dict[str, object]:
    state = SDESyncCompatState.objects.filter(pk=1).first()
    if not state:
        return {}

    return {
        "build_number": state.last_source_build_number,
        "release_date": (
            state.last_source_release_date.isoformat()
            if state.last_source_release_date
            else ""
        ),
        "last_synced_at": (
            state.last_synced_at.isoformat() if state.last_synced_at else ""
        ),
        "updated_at": state.updated_at.isoformat() if state.updated_at else "",
    }


def _chunked_ids(values: Sequence[int], size: int) -> Iterable[list[int]]:
    chunk_size = max(1, int(size or 1))
    for index in range(0, len(values), chunk_size):
        yield list(values[index : index + chunk_size])


def _project_workspace_scoped_sde_signature_cache_key(
    *,
    type_ids: Sequence[int],
    blueprint_type_ids: Sequence[int],
    global_signature: dict[str, object],
) -> str:
    cache_payload = json.dumps(
        {
            "version": PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_VERSION,
            "type_ids": list(type_ids),
            "blueprint_type_ids": list(blueprint_type_ids),
            "global_signature": global_signature,
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    digest = hashlib.sha256(cache_payload.encode("utf-8")).hexdigest()
    return f"indy_hub:craft-project:scoped-sde-signature:{digest}"


def _payload_uses_unpublished_blueprints(payload: dict[str, object] | None) -> bool:
    if not isinstance(payload, dict):
        return False

    blueprint_type_ids: set[int] = set()

    def collect(nodes: object) -> None:
        for node in nodes if isinstance(nodes, list) else []:
            if not isinstance(node, dict):
                continue
            blueprint_type_id = int(node.get("blueprint_type_id") or 0)
            if blueprint_type_id > 0:
                blueprint_type_ids.add(blueprint_type_id)
            collect(node.get("sub_materials"))

    collect(payload.get("materials_tree"))
    if not blueprint_type_ids:
        return False

    sorted_blueprint_type_ids = sorted(blueprint_type_ids)
    with connection.cursor() as cursor:
        for chunk in _chunked_ids(
            sorted_blueprint_type_ids,
            PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_QUERY_CHUNK_SIZE,
        ):
            placeholders = ", ".join(["%s"] * len(chunk))
            cursor.execute(
                f"""
                SELECT id
                FROM eve_sde_itemtype
                WHERE id IN ({placeholders}) AND COALESCE(published, 0) = 0
                LIMIT 1
                """,
                chunk,
            )
            if cursor.fetchone() is not None:
                return True
    return False


def _collect_payload_blueprint_type_ids(payload: dict[str, object] | None) -> set[int]:
    blueprint_type_ids: set[int] = set()
    if not isinstance(payload, dict):
        return blueprint_type_ids

    def collect(nodes: object) -> None:
        for node in nodes if isinstance(nodes, list) else []:
            if not isinstance(node, dict):
                continue
            blueprint_type_id = int(node.get("blueprint_type_id") or 0)
            if blueprint_type_id > 0:
                blueprint_type_ids.add(blueprint_type_id)
            collect(node.get("sub_materials"))

    collect(payload.get("materials_tree"))
    for key in ("bp_type_id", "type_id"):
        try:
            blueprint_type_id = int(payload.get(key) or 0)
        except (TypeError, ValueError):
            blueprint_type_id = 0
        if blueprint_type_id > 0:
            blueprint_type_ids.add(blueprint_type_id)

    page = payload.get("page")
    if isinstance(page, dict):
        blueprint_configs = page.get("blueprint_configs")
        for config in blueprint_configs if isinstance(blueprint_configs, list) else []:
            if not isinstance(config, dict):
                continue
            try:
                blueprint_type_id = int(config.get("type_id") or 0)
            except (TypeError, ValueError):
                continue
            if blueprint_type_id > 0:
                blueprint_type_ids.add(blueprint_type_id)

    final_outputs = payload.get("final_outputs")
    for output in final_outputs if isinstance(final_outputs, list) else []:
        if not isinstance(output, dict):
            continue
        try:
            blueprint_type_id = int(output.get("blueprint_type_id") or 0)
        except (TypeError, ValueError):
            continue
        if blueprint_type_id > 0:
            blueprint_type_ids.add(blueprint_type_id)
    return blueprint_type_ids


def _coerce_positive_type_id(value: object) -> int:
    try:
        type_id = int(value or 0)
    except (TypeError, ValueError):
        return 0
    return type_id if type_id > 0 else 0


def _collect_payload_type_ids(payload: dict[str, object] | None) -> set[int]:
    type_ids: set[int] = set()
    if not isinstance(payload, dict):
        return type_ids

    def add(value: object) -> None:
        type_id = _coerce_positive_type_id(value)
        if type_id > 0:
            type_ids.add(type_id)

    def collect_nodes(nodes: object) -> None:
        for node in nodes if isinstance(nodes, list) else []:
            if not isinstance(node, dict):
                continue
            add(node.get("type_id"))
            add(node.get("blueprint_type_id"))
            collect_nodes(node.get("sub_materials"))

    for key in ("bp_type_id", "type_id", "product_type_id"):
        add(payload.get(key))
    collect_nodes(payload.get("materials_tree"))

    for list_key in ("materials", "direct_materials", "final_outputs"):
        rows = payload.get(list_key)
        for row in rows if isinstance(rows, list) else []:
            if not isinstance(row, dict):
                continue
            add(row.get("type_id"))
            add(row.get("blueprint_type_id"))
            add(row.get("product_type_id"))

    page = payload.get("page")
    if isinstance(page, dict):
        blueprint_configs = page.get("blueprint_configs")
        for config in blueprint_configs if isinstance(blueprint_configs, list) else []:
            if not isinstance(config, dict):
                continue
            add(config.get("type_id"))
            add(config.get("product_type_id"))

    recipe_map = payload.get("recipe_map")
    if isinstance(recipe_map, dict):
        for raw_product_type_id, recipe in recipe_map.items():
            add(raw_product_type_id)
            if not isinstance(recipe, dict):
                continue
            for input_key in ("inputs_per_cycle", "inputs_per_cycle_me0"):
                inputs = recipe.get(input_key)
                for entry in inputs if isinstance(inputs, list) else []:
                    if isinstance(entry, dict):
                        add(entry.get("type_id"))

    cycle_summary = payload.get("craft_cycles_summary")
    if isinstance(cycle_summary, dict):
        for raw_type_id, entry in cycle_summary.items():
            add(raw_type_id)
            if isinstance(entry, dict):
                add(entry.get("type_id"))

    return type_ids


def get_project_workspace_scoped_sde_signature(
    payload: dict[str, object] | None,
) -> dict[str, object]:
    blueprint_type_ids = sorted(_collect_payload_blueprint_type_ids(payload))
    type_ids = sorted(_collect_payload_type_ids(payload) | set(blueprint_type_ids))
    global_signature = get_project_workspace_sde_signature()

    if (
        len(type_ids) > PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_ID_LIMIT
        or len(blueprint_type_ids) > PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_ID_LIMIT
    ):
        return {
            "version": PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_VERSION,
            "scope": "global-fallback",
            "type_id_count": len(type_ids),
            "blueprint_type_id_count": len(blueprint_type_ids),
            "global_signature": global_signature,
        }

    cache_key = _project_workspace_scoped_sde_signature_cache_key(
        type_ids=type_ids,
        blueprint_type_ids=blueprint_type_ids,
        global_signature=global_signature,
    )
    cached_signature = cache.get(cache_key)
    if isinstance(cached_signature, dict):
        return cached_signature

    signature: dict[str, object] = {
        "version": PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_VERSION,
        "blueprint_type_ids": blueprint_type_ids,
        "type_ids": type_ids,
        "item_types": [],
        "products": [],
        "materials": [],
        "activities": [],
    }

    if type_ids:
        item_type_rows = []
        with connection.cursor() as cursor:
            for chunk in _chunked_ids(
                type_ids,
                PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_QUERY_CHUNK_SIZE,
            ):
                placeholders = ", ".join(["%s"] * len(chunk))
                cursor.execute(
                    f"""
                    SELECT id, COALESCE(name_en, name), COALESCE(published, 0), group_id
                    FROM eve_sde_itemtype
                    WHERE id IN ({placeholders})
                    ORDER BY id
                    """,
                    chunk,
                )
                item_type_rows.extend(cursor.fetchall())
        signature["item_types"] = [
            {
                "type_id": int(type_id),
                "name": str(type_name or ""),
                "published": bool(published),
                "group_id": int(group_id) if group_id is not None else None,
            }
            for type_id, type_name, published, group_id in sorted(
                item_type_rows,
                key=lambda row: int(row[0]),
            )
        ]

    if not blueprint_type_ids:
        cache.set(
            cache_key,
            signature,
            PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_CACHE_TIMEOUT_SECONDS,
        )
        return signature

    product_rows = []
    material_rows = []
    activity_rows = []
    with connection.cursor() as cursor:
        for chunk in _chunked_ids(
            blueprint_type_ids,
            PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_QUERY_CHUNK_SIZE,
        ):
            placeholders = ", ".join(["%s"] * len(chunk))
            cursor.execute(
                f"""
                SELECT
                    p.eve_type_id,
                    p.activity_id,
                    p.product_eve_type_id,
                    p.quantity,
                    COALESCE(product_t.name_en, product_t.name),
                    COALESCE(product_t.published, 0),
                    product_t.group_id
                FROM indy_hub_sdeindustryactivityproduct p
                JOIN eve_sde_itemtype product_t ON product_t.id = p.product_eve_type_id
                WHERE p.eve_type_id IN ({placeholders})
                    AND p.activity_id IN (1, 11)
                ORDER BY p.eve_type_id, p.activity_id, p.product_eve_type_id
                """,
                chunk,
            )
            product_rows.extend(cursor.fetchall())

            cursor.execute(
                f"""
                SELECT
                    m.eve_type_id,
                    m.activity_id,
                    m.material_eve_type_id,
                    m.quantity,
                    COALESCE(material_t.name_en, material_t.name),
                    COALESCE(material_t.published, 0),
                    material_t.group_id
                FROM indy_hub_sdeindustryactivitymaterial m
                JOIN eve_sde_itemtype material_t ON material_t.id = m.material_eve_type_id
                WHERE m.eve_type_id IN ({placeholders})
                    AND m.activity_id IN (1, 11)
                ORDER BY m.eve_type_id, m.activity_id, m.material_eve_type_id
                """,
                chunk,
            )
            material_rows.extend(cursor.fetchall())

            cursor.execute(
                f"""
                SELECT eve_type_id, activity_id, time
                FROM indy_hub_sdeblueprintactivity
                WHERE eve_type_id IN ({placeholders})
                    AND activity_id IN (1, 11)
                ORDER BY eve_type_id, activity_id
                """,
                chunk,
            )
            activity_rows.extend(cursor.fetchall())

    signature["products"] = [
        {
            "blueprint_type_id": int(blueprint_type_id),
            "activity_id": int(activity_id),
            "product_type_id": int(product_type_id),
            "quantity": int(quantity or 0),
            "product_name": str(product_name or ""),
            "product_published": bool(product_published),
            "product_group_id": (
                int(product_group_id) if product_group_id is not None else None
            ),
        }
        for (
            blueprint_type_id,
            activity_id,
            product_type_id,
            quantity,
            product_name,
            product_published,
            product_group_id,
        ) in sorted(
            product_rows,
            key=lambda row: (int(row[0]), int(row[1]), int(row[2])),
        )
    ]
    signature["materials"] = [
        {
            "blueprint_type_id": int(blueprint_type_id),
            "activity_id": int(activity_id),
            "material_type_id": int(material_type_id),
            "quantity": int(quantity or 0),
            "material_name": str(material_name or ""),
            "material_published": bool(material_published),
            "material_group_id": (
                int(material_group_id) if material_group_id is not None else None
            ),
        }
        for (
            blueprint_type_id,
            activity_id,
            material_type_id,
            quantity,
            material_name,
            material_published,
            material_group_id,
        ) in sorted(
            material_rows,
            key=lambda row: (int(row[0]), int(row[1]), int(row[2])),
        )
    ]
    signature["activities"] = [
        {
            "blueprint_type_id": int(blueprint_type_id),
            "activity_id": int(activity_id),
            "time": int(activity_time or 0),
        }
        for blueprint_type_id, activity_id, activity_time in sorted(
            activity_rows,
            key=lambda row: (int(row[0]), int(row[1])),
        )
    ]

    cache.set(
        cache_key,
        signature,
        PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_CACHE_TIMEOUT_SECONDS,
    )
    return signature


def _get_cached_project_scoped_sde_signature(
    workspace_state: dict[str, object],
) -> dict[str, object] | None:
    cached_scoped_signature = workspace_state.get(
        PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_KEY
    )
    if not isinstance(cached_scoped_signature, dict):
        return None
    if (
        cached_scoped_signature.get("version")
        != PROJECT_WORKSPACE_SCOPED_SDE_SIGNATURE_VERSION
    ):
        return None
    return cached_scoped_signature


def _cached_payload_includes_blueprint_configs(
    cached_payload: dict[str, object] | None,
    workspace_state: dict[str, object] | None,
) -> bool:
    if not isinstance(cached_payload, dict):
        return False

    used_blueprint_type_ids = _collect_payload_blueprint_type_ids(cached_payload)
    if isinstance(workspace_state, dict):
        try:
            workspace_blueprint_type_id = int(
                workspace_state.get("blueprint_type_id") or 0
            )
        except (TypeError, ValueError):
            workspace_blueprint_type_id = 0
        if workspace_blueprint_type_id > 0:
            used_blueprint_type_ids.add(workspace_blueprint_type_id)
    if not used_blueprint_type_ids:
        return True

    page = cached_payload.get("page")
    if not isinstance(page, dict):
        return True
    blueprint_configs = page.get("blueprint_configs")
    configured_blueprint_type_ids: set[int] = set()
    for config in blueprint_configs if isinstance(blueprint_configs, list) else []:
        if not isinstance(config, dict):
            continue
        try:
            blueprint_type_id = int(config.get("type_id") or 0)
        except (TypeError, ValueError):
            continue
        if blueprint_type_id > 0:
            configured_blueprint_type_ids.add(blueprint_type_id)
    return used_blueprint_type_ids.issubset(configured_blueprint_type_ids)


def cached_project_workspace_payload_matches_state(
    cached_payload: dict[str, object] | None,
    workspace_state: dict[str, object] | None,
) -> bool:
    if not isinstance(cached_payload, dict):
        return False

    normalized_workspace_state = strip_project_workspace_cache(workspace_state)
    if normalized_workspace_state.get("pendingWorkspaceRefresh"):
        return False

    if not _cached_payload_includes_blueprint_configs(
        cached_payload,
        normalized_workspace_state,
    ):
        return False

    try:
        saved_runs = max(1, int(normalized_workspace_state.get("runs") or 1))
    except (TypeError, ValueError):
        saved_runs = 1

    payload_runs = cached_payload.get("num_runs")
    if payload_runs is None:
        return True

    try:
        normalized_payload_runs = max(1, int(payload_runs or 1))
    except (TypeError, ValueError):
        return False

    return normalized_payload_runs == saved_runs


def get_cached_project_workspace_payload(
    project: ProductionProject,
) -> tuple[dict[str, object] | None, bool]:
    workspace_state = dict(project.workspace_state or {})
    cached_payload = workspace_state.get(PROJECT_WORKSPACE_PAYLOAD_CACHE_KEY)
    if not isinstance(cached_payload, dict):
        return None, False
    if not cached_project_workspace_payload_matches_state(
        cached_payload, workspace_state
    ):
        logger.info(
            "Discarding cached craft payload for project %s because it is out of sync with the saved workspace state.",
            getattr(project, "id", None),
        )
        return None, False
    if _payload_uses_unpublished_blueprints(cached_payload):
        logger.info(
            "Discarding cached craft payload for project %s because it references unpublished blueprint types.",
            getattr(project, "id", None),
        )
        return None, False

    cached_signature = workspace_state.get(PROJECT_WORKSPACE_SDE_SIGNATURE_KEY)
    payload = dict(cached_payload)
    payload.update(
        {
            "project_id": project.id,
            "project_ref": project.project_ref,
            "name": project.name,
            "project_status": project.status,
            "source_kind": project.source_kind,
            "workspace_state": strip_project_workspace_cache(workspace_state),
        }
    )
    cached_scoped_signature = _get_cached_project_scoped_sde_signature(workspace_state)
    if cached_scoped_signature is not None:
        current_scoped_signature = get_project_workspace_scoped_sde_signature(payload)
        sde_has_changed = cached_scoped_signature != current_scoped_signature
    else:
        current_signature = get_project_workspace_sde_signature()
        sde_has_changed = bool(
            cached_signature and cached_signature != current_signature
        )
    return payload, sde_has_changed


def _resolve_preferred_blueprint_for_product(product_type_id: int) -> int | None:
    numeric_product_type_id = int(product_type_id or 0)
    if numeric_product_type_id <= 0:
        return None

    with connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT p.eve_type_id
            FROM indy_hub_sdeindustryactivityproduct p
                        JOIN eve_sde_itemtype t ON t.id = p.eve_type_id
                        JOIN eve_sde_itemtype product_t ON product_t.id = p.product_eve_type_id
                        WHERE p.product_eve_type_id = %s
                            AND p.activity_id IN (1, 11)
                            AND COALESCE(t.published, 0) = 1
                            AND COALESCE(product_t.published, 0) = 1
                        ORDER BY CASE p.activity_id WHEN 1 THEN 0 WHEN 11 THEN 1 ELSE 99 END,
                        p.eve_type_id ASC
            LIMIT 1
            """,
            [numeric_product_type_id],
        )
        row = cursor.fetchone()

    return int(row[0]) if row and row[0] is not None else None


def detect_project_import_kind(raw_text: str) -> str:
    """Return the most likely import kind for raw project input."""

    first_line = next(
        (line.strip() for line in raw_text.splitlines() if line.strip()), ""
    )
    if first_line and EFT_HEADER_RE.match(first_line):
        return "eft"
    return "manual"


def parse_project_import_text(
    raw_text: str,
    *,
    preferred_kind: str | None = None,
) -> dict[str, object]:
    """Parse EFT or manual input into normalized import entries."""

    normalized_text = (raw_text or "").replace("\r\n", "\n")
    kind = preferred_kind or detect_project_import_kind(normalized_text)

    if kind == "eft":
        return _parse_eft_project_import(normalized_text)
    return _parse_manual_project_import(normalized_text)


def normalize_production_project_ref(project_ref: str) -> str:
    """Validate and normalize a fixed-width base36 project token."""

    token = str(project_ref or "").strip().lower()
    if len(token) != PROJECT_REF_LENGTH:
        raise ValueError("Invalid production project token length.")
    if any(char not in PROJECT_REF_BASE36_ALPHABET for char in token):
        raise ValueError("Invalid production project token alphabet.")
    return token


def aggregate_project_import_entries(
    entries: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    """Aggregate duplicate import entries into one line with summed quantities."""

    aggregated: OrderedDict[str, dict[str, object]] = OrderedDict()
    for entry in entries:
        type_name = str(entry.get("type_name") or "").strip()
        if not type_name:
            continue

        quantity = max(1, int(entry.get("quantity") or 1))
        aggregate_key = str(entry.get("type_id") or "").strip() or type_name.casefold()
        category_key = str(entry.get("category_key") or "")
        category_label = str(entry.get("category_label") or "")
        category_order = _coerce_category_order(entry.get("category_order"))

        if aggregate_key not in aggregated:
            aggregated[aggregate_key] = {
                "type_id": entry.get("type_id"),
                "type_name": type_name,
                "quantity": quantity,
                "category_key": category_key,
                "category_label": category_label,
                "category_order": category_order,
                "categories": (
                    [
                        {
                            "key": category_key,
                            "label": category_label,
                            "order": category_order,
                        }
                    ]
                    if category_key or category_label
                    else []
                ),
                "source_lines": [str(entry.get("source_line") or type_name)],
            }
            continue

        current = aggregated[aggregate_key]
        current["quantity"] = int(current.get("quantity") or 0) + quantity
        current["source_lines"].append(str(entry.get("source_line") or type_name))

        seen_category_keys = {
            str(cat.get("key") or "") for cat in current.get("categories", [])
        }
        if category_key and category_key not in seen_category_keys:
            current.setdefault("categories", []).append(
                {
                    "key": category_key,
                    "label": category_label,
                    "order": category_order,
                }
            )

        current_order = _coerce_category_order(current.get("category_order"))
        if category_order < current_order:
            current["category_order"] = category_order
            current["category_key"] = category_key
            current["category_label"] = category_label

    return list(aggregated.values())


def resolve_project_import_entries(
    entries: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    """Resolve imported names against SDE and annotate craftability."""

    if not entries:
        return []

    names = []
    seen_names: set[str] = set()
    for entry in entries:
        normalized_name = str(entry.get("type_name") or "").strip()
        if not normalized_name:
            continue
        lowered = normalized_name.casefold()
        if lowered in seen_names:
            continue
        seen_names.add(lowered)
        names.append(normalized_name)

    resolved_type_map = _resolve_item_types_by_name(names)
    blueprint_map = _resolve_blueprints_for_products(
        [
            info["type_id"]
            for info in resolved_type_map.values()
            if info.get("type_id") is not None
        ]
    )

    resolved_entries: list[dict[str, object]] = []
    for entry in entries:
        type_name = str(entry.get("type_name") or "").strip()
        resolved_info = resolved_type_map.get(type_name.casefold())
        enriched = dict(entry)

        if not resolved_info:
            enriched.update(
                {
                    "resolved": False,
                    "type_id": None,
                    "is_craftable": False,
                    "blueprint_type_id": None,
                    "not_craftable_reason": "unknown_item",
                }
            )
            resolved_entries.append(enriched)
            continue

        type_id = int(resolved_info["type_id"])
        blueprint_type_id = blueprint_map.get(type_id)
        enriched.update(
            {
                "resolved": True,
                "type_id": type_id,
                "type_name": resolved_info.get("type_name") or type_name,
                "group_name": resolved_info.get("group_name") or "",
                "is_craftable": blueprint_type_id is not None,
                "blueprint_type_id": blueprint_type_id,
                "not_craftable_reason": None if blueprint_type_id else "no_blueprint",
            }
        )
        category_override = _normalize_resolved_eft_category(
            enriched,
            str(resolved_info.get("group_name") or ""),
        )
        if category_override:
            enriched.update(
                {
                    "category_key": str(category_override["key"]),
                    "category_label": str(category_override["label"]),
                    "category_order": int(category_override["order"]),
                    "categories": [
                        {
                            "key": str(category_override["key"]),
                            "label": str(category_override["label"]),
                            "order": int(category_override["order"]),
                        }
                    ],
                }
            )
        resolved_entries.append(enriched)

    return resolved_entries


def build_project_import_preview(
    raw_text: str,
    *,
    preferred_kind: str | None = None,
) -> dict[str, object]:
    """Parse, aggregate and resolve import text for project preview."""

    parsed = parse_project_import_text(raw_text, preferred_kind=preferred_kind)
    aggregated = aggregate_project_import_entries(parsed["entries"])
    resolved_entries = resolve_project_import_entries(aggregated)
    grouped_entries = _group_project_entries(resolved_entries)

    return {
        "source_kind": parsed["source_kind"],
        "source_name": parsed.get("source_name") or "",
        "entries": resolved_entries,
        "groups": grouped_entries,
        "summary": {
            "total_lines": len(parsed["entries"]),
            "total_unique_items": len(resolved_entries),
            "total_quantity": sum(
                int(entry.get("quantity") or 0) for entry in resolved_entries
            ),
            "craftable_items": sum(
                1 for entry in resolved_entries if entry.get("is_craftable")
            ),
            "non_craftable_items": sum(
                1 for entry in resolved_entries if not entry.get("is_craftable")
            ),
            "unresolved_items": sum(
                1 for entry in resolved_entries if not entry.get("resolved")
            ),
        },
    }


def parse_project_me_te_overrides(query_params) -> dict[int, dict[str, int]]:
    """Parse per-blueprint ME/TE overrides from request query params."""

    overrides: dict[int, dict[str, int]] = {}
    for key, value in query_params.items():
        if not value:
            continue
        try:
            numeric_value = int(value)
        except (TypeError, ValueError):
            continue

        if key.startswith("me_"):
            try:
                blueprint_type_id = int(key.replace("me_", "", 1))
            except (TypeError, ValueError):
                continue
            overrides.setdefault(blueprint_type_id, {})["me"] = max(
                0, min(numeric_value, 10)
            )
        elif key.startswith("te_"):
            try:
                blueprint_type_id = int(key.replace("te_", "", 1))
            except (TypeError, ValueError):
                continue
            overrides.setdefault(blueprint_type_id, {})["te"] = max(
                0, min(numeric_value, 20)
            )
    return overrides


def _clamp_blueprint_me(value) -> int:
    try:
        return max(0, min(int(value or 0), 10))
    except (TypeError, ValueError):
        return 0


def _clamp_blueprint_te(value) -> int:
    try:
        return max(0, min(int(value or 0), 20))
    except (TypeError, ValueError):
        return 0


def _select_best_owned_blueprint_entry(
    user_entry: dict[str, object],
) -> tuple[dict[str, object] | None, bool]:
    candidates: list[tuple[dict[str, object], bool]] = []
    original = user_entry.get("original")
    if isinstance(original, dict) and original:
        candidates.append((original, False))
    best_copy = user_entry.get("best_copy")
    if isinstance(best_copy, dict) and best_copy:
        candidates.append((best_copy, True))
    if not candidates:
        return None, False

    return max(
        candidates,
        key=lambda candidate: (
            _clamp_blueprint_me(candidate[0].get("me")),
            _clamp_blueprint_te(candidate[0].get("te")),
            0 if candidate[1] else 1,
        ),
    )


def _extract_workspace_me_te_overrides(
    workspace_state: dict[str, object] | None,
) -> dict[int, dict[str, int]]:
    """Extract saved per-blueprint ME/TE choices from project workspace state."""

    state = workspace_state if isinstance(workspace_state, dict) else {}
    overrides: dict[int, dict[str, int]] = {}
    me_te_config = state.get("meTeConfig")
    if isinstance(me_te_config, dict):
        blueprint_configs = me_te_config.get("blueprintConfigs")
        if isinstance(blueprint_configs, dict):
            for raw_type_id, raw_config in blueprint_configs.items():
                try:
                    blueprint_type_id = int(raw_type_id)
                except (TypeError, ValueError):
                    continue
                if blueprint_type_id <= 0 or not isinstance(raw_config, dict):
                    continue
                entry: dict[str, int] = {}
                if "me" in raw_config:
                    entry["me"] = _clamp_blueprint_me(raw_config.get("me"))
                if "te" in raw_config:
                    entry["te"] = _clamp_blueprint_te(raw_config.get("te"))
                if entry:
                    overrides[blueprint_type_id] = entry
        return overrides

    for raw_config in state.get("blueprint_efficiencies") or []:
        if not isinstance(raw_config, dict):
            continue
        try:
            blueprint_type_id = int(raw_config.get("blueprint_type_id") or 0)
        except (TypeError, ValueError):
            continue
        if blueprint_type_id <= 0:
            continue
        me = _clamp_blueprint_me(raw_config.get("material_efficiency"))
        te = _clamp_blueprint_te(raw_config.get("time_efficiency"))
        if me or te:
            overrides[blueprint_type_id] = {"me": me, "te": te}
    return overrides


def _merge_me_te_overrides(
    *sources: dict[int, dict[str, int]] | None,
) -> dict[int, dict[str, int]]:
    merged: dict[int, dict[str, int]] = {}
    for source in sources:
        for raw_type_id, raw_config in (source or {}).items():
            try:
                blueprint_type_id = int(raw_type_id)
            except (TypeError, ValueError):
                continue
            if blueprint_type_id <= 0 or not isinstance(raw_config, dict):
                continue
            entry = merged.setdefault(blueprint_type_id, {})
            if "me" in raw_config:
                entry["me"] = _clamp_blueprint_me(raw_config.get("me"))
            if "te" in raw_config:
                entry["te"] = _clamp_blueprint_te(raw_config.get("te"))
    return merged


def _remember_project_blueprint_for_product(
    product_blueprint_cache: dict[int, int | None],
    product_type_id: int | None,
    blueprint_type_id: int | None,
) -> None:
    numeric_product_type_id = int(product_type_id or 0)
    numeric_blueprint_type_id = int(blueprint_type_id or 0)
    if numeric_product_type_id > 0 and numeric_blueprint_type_id > 0:
        product_blueprint_cache[numeric_product_type_id] = numeric_blueprint_type_id


def create_project_from_entries(
    *,
    user,
    name: str,
    status: str,
    source_kind: str,
    source_text: str,
    source_name: str,
    selected_entries: Sequence[dict[str, object]],
    notes: str = "",
) -> ProductionProject:
    """Persist a production project with its selected aggregated entries."""

    project = ProductionProject.objects.create(
        user=user,
        name=(name or source_name or "New production project").strip()[:255],
        status=status,
        source_kind=source_kind,
        source_text=source_text,
        source_name=(source_name or "").strip()[:255],
        notes=notes,
        summary={
            "selected_items": len(selected_entries),
            "selected_quantity": sum(
                max(0, int(entry.get("quantity") or 0)) for entry in selected_entries
            ),
            "craftable_items": sum(
                1 for entry in selected_entries if entry.get("is_craftable")
            ),
            "buy_items": sum(
                1 for entry in selected_entries if entry.get("inclusion_mode") == "buy"
            ),
        },
    )

    item_rows: list[ProductionProjectItem] = []
    for entry in selected_entries:
        inclusion_mode = str(entry.get("inclusion_mode") or "produce")
        item_rows.append(
            ProductionProjectItem(
                project=project,
                type_id=entry.get("type_id"),
                type_name=str(entry.get("type_name") or "").strip()[:255],
                quantity_requested=max(1, int(entry.get("quantity") or 1)),
                category_key=str(entry.get("category_key") or "")[:64],
                category_label=str(entry.get("category_label") or "")[:255],
                category_order=_coerce_category_order(entry.get("category_order")),
                source_line=str(entry.get("source_line") or "")[:65535],
                is_selected=True,
                is_craftable=bool(entry.get("is_craftable")),
                inclusion_mode=inclusion_mode,
                blueprint_type_id=entry.get("blueprint_type_id"),
                metadata={
                    "group_name": entry.get("group_name") or "",
                    "categories": entry.get("categories") or [],
                    "source_lines": entry.get("source_lines") or [],
                    "not_craftable_reason": entry.get("not_craftable_reason"),
                },
            )
        )
    if item_rows:
        ProductionProjectItem.objects.bulk_create(item_rows)
    return project


def _get_blueprint_output_quantity(blueprint_type_id: int) -> int:
    with connection.cursor() as cursor:
        cursor.execute(
            """
            SELECT p.quantity
            FROM indy_hub_sdeindustryactivityproduct p
            JOIN eve_sde_itemtype blueprint_t ON blueprint_t.id = p.eve_type_id
            JOIN eve_sde_itemtype product_t ON product_t.id = p.product_eve_type_id
            WHERE p.eve_type_id = %s
                        AND p.activity_id IN (1, 11)
                        AND COALESCE(blueprint_t.published, 0) = 1
                        AND COALESCE(product_t.published, 0) = 1
            ORDER BY CASE activity_id WHEN 1 THEN 0 WHEN 11 THEN 1 ELSE 99 END
            LIMIT 1
            """,
            [int(blueprint_type_id)],
        )
        row = cursor.fetchone()
    return max(1, int((row[0] if row else 1) or 1))


def _get_project_item_base_quantity_for_runs(
    *,
    project: ProductionProject,
    item: ProductionProjectItem,
    saved_runs: int,
    is_single_item_project: bool,
) -> int:
    raw_quantity = max(1, int(item.quantity_requested or 1))
    normalized_saved_runs = max(1, int(saved_runs or 1))
    if (
        is_single_item_project
        and normalized_saved_runs > 1
        and str(project.notes or "").strip() == LEGACY_SINGLE_BLUEPRINT_PROJECT_NOTE
    ):
        blueprint_type_id = int(item.blueprint_type_id or 0)
        if blueprint_type_id > 0:
            output_quantity = _get_blueprint_output_quantity(blueprint_type_id)
            if raw_quantity == output_quantity * normalized_saved_runs:
                return output_quantity
    return raw_quantity


def _scale_project_selected_items_for_runs(
    *,
    project: ProductionProject,
    selected_items: Sequence[ProductionProjectItem],
    saved_runs: int,
    target_runs: int,
) -> list[ProductionProjectItem]:
    normalized_saved_runs = max(1, int(saved_runs or 1))
    normalized_target_runs = max(1, int(target_runs or 1))
    is_single_item_project = len(selected_items) == 1

    scaled_items: list[ProductionProjectItem] = []
    for item in selected_items:
        scaled_item = copy(item)
        base_quantity = _get_project_item_base_quantity_for_runs(
            project=project,
            item=item,
            saved_runs=normalized_saved_runs,
            is_single_item_project=is_single_item_project,
        )
        scaled_item.quantity_requested = max(1, base_quantity * normalized_target_runs)
        scaled_items.append(scaled_item)

    return scaled_items


def create_project_from_single_blueprint(
    *,
    user,
    blueprint_type_id: int,
    blueprint_name: str,
    runs: int = 1,
    name: str = "",
    status: str = ProductionProject.Status.DRAFT,
    me: int = 0,
    te: int = 0,
    active_tab: str = "materials",
    workspace_state: dict[str, object] | None = None,
) -> ProductionProject:
    numeric_blueprint_type_id = int(blueprint_type_id)
    resolved_blueprint_type_id = numeric_blueprint_type_id
    product_type_id = get_blueprint_product_type_id(resolved_blueprint_type_id)
    if not product_type_id:
        resolved_blueprint_type_id = (
            _resolve_blueprints_for_products([numeric_blueprint_type_id]).get(
                numeric_blueprint_type_id
            )
            or numeric_blueprint_type_id
        )
        product_type_id = get_blueprint_product_type_id(resolved_blueprint_type_id)

    safe_runs = max(1, int(runs or 1))
    product_type_name = get_type_name(product_type_id) if product_type_id else ""
    resolved_blueprint_name = (
        get_type_name(resolved_blueprint_type_id)
        or blueprint_name
        or product_type_name
        or str(resolved_blueprint_type_id)
    )
    output_quantity = _get_blueprint_output_quantity(resolved_blueprint_type_id)
    final_quantity = max(1, output_quantity * safe_runs)

    project = create_project_from_entries(
        user=user,
        name=(
            name
            or product_type_name
            or resolved_blueprint_name
            or "New production project"
        ),
        status=(
            status
            if status in ProductionProject.Status.values
            else ProductionProject.Status.DRAFT
        ),
        source_kind=ProductionProject.SourceKind.MANUAL,
        source_text=str(resolved_blueprint_name or "").strip(),
        source_name=str(resolved_blueprint_name or "").strip(),
        selected_entries=[
            {
                "type_id": product_type_id,
                "type_name": product_type_name
                or resolved_blueprint_name
                or str(resolved_blueprint_type_id),
                "quantity": final_quantity,
                "category_key": "manual",
                "category_label": "Manual list",
                "category_order": 90,
                "source_line": product_type_name
                or resolved_blueprint_name
                or str(resolved_blueprint_type_id),
                "is_craftable": True,
                "blueprint_type_id": resolved_blueprint_type_id,
                "inclusion_mode": ProductionProjectItem.InclusionMode.PRODUCE,
            }
        ],
        notes=LEGACY_SINGLE_BLUEPRINT_PROJECT_NOTE,
    )

    persisted_workspace_state = dict(workspace_state or {})
    if not persisted_workspace_state:
        persisted_workspace_state = {
            "blueprint_type_id": resolved_blueprint_type_id,
            "blueprint_name": resolved_blueprint_name,
            "runs": safe_runs,
            "active_tab": active_tab or "materials",
            "items": [],
            "blueprint_efficiencies": [
                {
                    "blueprint_type_id": resolved_blueprint_type_id,
                    "material_efficiency": max(0, min(int(me or 0), 10)),
                    "time_efficiency": max(0, min(int(te or 0), 20)),
                }
            ],
            "custom_prices": [],
        }

    project.workspace_state = persisted_workspace_state
    project.save(update_fields=["workspace_state", "updated_at"])
    return project


def build_project_workspace_payload(
    project: ProductionProject,
    *,
    skill_cache_ttl=timedelta(hours=1),
    me_te_overrides: dict[int, dict[str, int]] | None = None,
    runs_override: int | None = None,
    include_full_structure_options: bool = True,
) -> dict[str, object]:
    """Build a craft workspace payload for a multi-product project."""

    profile_started_at = perf_counter()
    workspace_timing_steps: list[dict[str, object]] = []

    def record_timing_step(step_id: str, label: str, started_at: float) -> None:
        workspace_timing_steps.append(
            {
                "id": step_id,
                "label": label,
                "duration_ms": round((perf_counter() - started_at) * 1000, 1),
            }
        )

    def build_workspace_timing() -> dict[str, object]:
        return {
            "total_ms": round((perf_counter() - profile_started_at) * 1000, 1),
            "steps": workspace_timing_steps,
        }

    selected_items_started_at = perf_counter()
    selected_items = list(
        project.items.filter(is_selected=True)
        .exclude(inclusion_mode=ProductionProjectItem.InclusionMode.SKIP)
        .order_by("category_order", "id")
    )
    record_timing_step(
        "selected-items", "Project items query", selected_items_started_at
    )

    workspace_state = strip_project_workspace_cache(project.workspace_state)
    overrides = _merge_me_te_overrides(
        _extract_workspace_me_te_overrides(workspace_state),
        me_te_overrides,
    )
    owned_blueprint_inventory_map: dict[int, dict[str, object]] = {}
    owned_blueprint_efficiency_cache: dict[int, dict[str, int]] = {}

    def get_owned_blueprint_efficiency(blueprint_type_id: int) -> dict[str, int]:
        numeric_blueprint_type_id = int(blueprint_type_id or 0)
        if numeric_blueprint_type_id <= 0:
            return {}
        if numeric_blueprint_type_id in owned_blueprint_efficiency_cache:
            return owned_blueprint_efficiency_cache[numeric_blueprint_type_id]

        user_entry = owned_blueprint_inventory_map.get(numeric_blueprint_type_id, {})
        owned_entry, _is_copy = _select_best_owned_blueprint_entry(user_entry)
        owned_blueprint_efficiency_cache[numeric_blueprint_type_id] = (
            {
                "me": _clamp_blueprint_me(owned_entry.get("me")),
                "te": _clamp_blueprint_te(owned_entry.get("te")),
            }
            if owned_entry
            else {}
        )
        return owned_blueprint_efficiency_cache[numeric_blueprint_type_id]

    def get_effective_blueprint_efficiency(blueprint_type_id: int) -> dict[str, int]:
        numeric_blueprint_type_id = int(blueprint_type_id or 0)
        if numeric_blueprint_type_id <= 0:
            return {"me": 0, "te": 0}
        override = overrides.get(numeric_blueprint_type_id) or {}
        owned_efficiency = get_owned_blueprint_efficiency(numeric_blueprint_type_id)
        return {
            "me": (
                _clamp_blueprint_me(override.get("me"))
                if "me" in override
                else _clamp_blueprint_me(owned_efficiency.get("me"))
            ),
            "te": (
                _clamp_blueprint_te(override.get("te"))
                if "te" in override
                else _clamp_blueprint_te(owned_efficiency.get("te"))
            ),
        }

    saved_runs = max(1, int(workspace_state.get("runs") or 1))
    if runs_override is not None:
        try:
            target_runs = max(1, int(runs_override))
        except (TypeError, ValueError):
            target_runs = 1
    else:
        target_runs = saved_runs
    workspace_state["runs"] = target_runs

    if not selected_items:
        return {
            "type_id": 0,
            "bp_type_id": 0,
            "project_id": project.id,
            "project_ref": project.project_ref,
            "name": project.name,
            "project_status": project.status,
            "source_kind": project.source_kind,
            "workspace_state": workspace_state,
            "product_type_id": None,
            "final_product_qty": 0,
            "materials_tree": [],
            "materials": [],
            "direct_materials": [],
            "materials_by_group": {},
            "market_group_map": {},
            "recipe_map": {},
            "craft_cycles_summary": {},
            "blueprint_configs_grouped": [],
            "production_time_map": {},
            "craft_character_advisor": {"characters": [], "items": {}, "summary": {}},
            "structure_planner": {
                "items": [],
                "structures": [],
                "summary": {"has_structures": False},
            },
            "final_outputs": [],
            "page": {
                "blueprint_configs": [],
                "craft_cycles_summary_static": {},
                "main_bp_info": {},
                "workspace_timing": build_workspace_timing(),
            },
        }

    selected_items = _scale_project_selected_items_for_runs(
        project=project,
        selected_items=selected_items,
        saved_runs=saved_runs,
        target_runs=target_runs,
    )

    blueprint_product_cache: dict[int, dict[str, object] | None] = {}
    blueprint_recipe_cache: dict[tuple[int, int], dict[str, object]] = {}
    blueprint_material_rows_cache: dict[int, list[tuple[int, str, int]]] = {}
    product_blueprint_cache: dict[int, int | None] = {}
    type_meta_cache: dict[int, tuple[int | None, int | None]] = {}
    type_name_cache_started_at = perf_counter()
    type_name_cache = _resolve_type_names(
        [
            value
            for item in selected_items
            for value in (item.type_id, item.blueprint_type_id)
            if value
        ]
    )
    record_timing_step("type-names", "Resolve type names", type_name_cache_started_at)
    market_group_cache: dict[int, dict[str, object]] = {}
    recipe_map: dict[int, dict[str, object]] = {}

    def get_type_meta(type_id: int) -> tuple[int | None, int | None]:
        numeric_type_id = int(type_id or 0)
        if numeric_type_id <= 0:
            return (None, None)
        if numeric_type_id in type_meta_cache:
            return type_meta_cache[numeric_type_id]

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT t.meta_group_id_raw, g.category_id
                FROM eve_sde_itemtype t
                LEFT JOIN eve_sde_itemgroup g ON t.group_id = g.id
                WHERE t.id = %s AND COALESCE(t.published, 0) = 1
                LIMIT 1
                """,
                [numeric_type_id],
            )
            row = cursor.fetchone()

        type_meta_cache[numeric_type_id] = (
            int(row[0]) if row and row[0] is not None else None,
            int(row[1]) if row and row[1] is not None else None,
        )
        return type_meta_cache[numeric_type_id]

    def get_market_group_info(type_id: int) -> dict[str, object]:
        numeric_type_id = int(type_id or 0)
        if numeric_type_id <= 0:
            return {"group_name": "", "group_id": None}
        if numeric_type_id in market_group_cache:
            return market_group_cache[numeric_type_id]

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT COALESCE(g.name, ''), g.id
                FROM eve_sde_itemtype t
                LEFT JOIN eve_sde_itemgroup g ON t.group_id = g.id
                WHERE t.id = %s AND COALESCE(t.published, 0) = 1
                LIMIT 1
                """,
                [numeric_type_id],
            )
            row = cursor.fetchone()

        market_group_cache[numeric_type_id] = {
            "group_name": str(row[0] or "") if row else "",
            "group_id": int(row[1]) if row and row[1] is not None else None,
        }
        return market_group_cache[numeric_type_id]

    def get_blueprint_product_row(blueprint_type_id: int) -> dict[str, object] | None:
        numeric_blueprint_type_id = int(blueprint_type_id or 0)
        if numeric_blueprint_type_id <= 0:
            return None
        if numeric_blueprint_type_id in blueprint_product_cache:
            return blueprint_product_cache[numeric_blueprint_type_id]

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT
                    p.product_eve_type_id,
                    COALESCE(t.name_en, t.name),
                    p.quantity,
                    p.activity_id,
                    COALESCE(g.name, ''),
                    g.id
                FROM indy_hub_sdeindustryactivityproduct p
                                JOIN eve_sde_itemtype t ON t.id = p.product_eve_type_id
                                JOIN eve_sde_itemtype blueprint_t ON blueprint_t.id = p.eve_type_id
                LEFT JOIN eve_sde_itemgroup g ON t.group_id = g.id
                                WHERE p.eve_type_id = %s
                                    AND p.activity_id IN (1, 11)
                                    AND COALESCE(t.published, 0) = 1
                                    AND COALESCE(blueprint_t.published, 0) = 1
                ORDER BY CASE p.activity_id WHEN 1 THEN 0 WHEN 11 THEN 1 ELSE 99 END
                LIMIT 1
                """,
                [numeric_blueprint_type_id],
            )
            row = cursor.fetchone()

        blueprint_product_cache[numeric_blueprint_type_id] = (
            {
                "product_type_id": int(row[0]),
                "product_type_name": str(row[1] or ""),
                "produced_per_cycle": int(row[2] or 1),
                "activity_id": int(row[3] or 1),
                "group_name": str(row[4] or ""),
                "group_id": int(row[5]) if row[5] is not None else None,
            }
            if row
            else None
        )
        return blueprint_product_cache[numeric_blueprint_type_id]

    def get_blueprint_for_product(product_type_id: int) -> int | None:
        numeric_product_type_id = int(product_type_id or 0)
        if numeric_product_type_id <= 0:
            return None
        if numeric_product_type_id in product_blueprint_cache:
            return product_blueprint_cache[numeric_product_type_id]

        product_blueprint_cache[numeric_product_type_id] = (
            _resolve_preferred_blueprint_for_product(numeric_product_type_id)
        )
        return product_blueprint_cache[numeric_product_type_id]

    def material_efficiency_applies(
        blueprint_type_id: int,
        material_type_id: int,
    ) -> bool:
        blueprint_product = get_blueprint_product_row(blueprint_type_id)
        if not blueprint_product:
            return True

        parent_meta_group_id, parent_category_id = get_type_meta(
            int(blueprint_product["product_type_id"])
        )
        material_meta_group_id, material_category_id = get_type_meta(material_type_id)
        return not is_base_item_material_efficiency_exempt(
            parent_meta_group_id,
            parent_category_id,
            material_meta_group_id,
            material_category_id,
        )

    def build_recipe_entry(
        blueprint_type_id: int,
        blueprint_me: int = 0,
    ) -> dict[str, object]:
        cache_key = (int(blueprint_type_id), int(blueprint_me or 0))
        if cache_key in blueprint_recipe_cache:
            return blueprint_recipe_cache[cache_key]

        product_row = get_blueprint_product_row(blueprint_type_id) or {}
        produced_per_cycle = int(product_row.get("produced_per_cycle") or 1)
        adjusted_inputs = []
        me0_inputs = []
        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT m.material_eve_type_id, m.quantity
                FROM indy_hub_sdeindustryactivitymaterial m
                JOIN eve_sde_itemtype t ON t.id = m.material_eve_type_id
                WHERE m.eve_type_id = %s
                                AND m.activity_id IN (1, 11)
                                AND COALESCE(t.published, 0) = 1
                """,
                [int(blueprint_type_id)],
            )
            for material_type_id, base_quantity in cursor.fetchall():
                raw_qty = int(base_quantity or 0)
                if raw_qty <= 0:
                    continue
                adjusted_qty = ceil(raw_qty * (100 - int(blueprint_me or 0)) / 100)
                if adjusted_qty > 0:
                    adjusted_inputs.append(
                        {
                            "type_id": int(material_type_id),
                            "quantity": int(adjusted_qty),
                        }
                    )
                me0_inputs.append(
                    {"type_id": int(material_type_id), "quantity": int(raw_qty)}
                )

        blueprint_recipe_cache[cache_key] = {
            "produced_per_cycle": produced_per_cycle,
            "inputs_per_cycle": adjusted_inputs,
            "inputs_per_cycle_me0": me0_inputs,
        }
        return blueprint_recipe_cache[cache_key]

    def get_blueprint_material_rows(
        blueprint_type_id: int,
    ) -> list[tuple[int, str, int]]:
        numeric_blueprint_type_id = int(blueprint_type_id or 0)
        if numeric_blueprint_type_id <= 0:
            return []
        if numeric_blueprint_type_id in blueprint_material_rows_cache:
            return blueprint_material_rows_cache[numeric_blueprint_type_id]

        with connection.cursor() as cursor:
            cursor.execute(
                """
                SELECT m.material_eve_type_id, COALESCE(t.name_en, t.name), m.quantity
                FROM indy_hub_sdeindustryactivitymaterial m
                JOIN eve_sde_itemtype t ON t.id = m.material_eve_type_id
                                WHERE m.eve_type_id = %s
                                    AND m.activity_id IN (1, 11)
                                    AND COALESCE(t.published, 0) = 1
                """,
                [numeric_blueprint_type_id],
            )
            rows = [
                (
                    int(material_type_id),
                    str(material_name or ""),
                    int(base_quantity or 0),
                )
                for material_type_id, material_name, base_quantity in cursor.fetchall()
            ]

        blueprint_material_rows_cache[numeric_blueprint_type_id] = rows
        return rows

    def collect_project_blueprint_type_ids() -> set[int]:
        blueprint_type_ids: set[int] = set()

        def collect_output_blueprints(
            *,
            type_id: int | None,
            blueprint_type_id: int | None,
            seen: set[int] | None = None,
        ) -> None:
            numeric_type_id = int(type_id or 0) if type_id else None
            numeric_blueprint_type_id = (
                int(blueprint_type_id or 0) if blueprint_type_id else 0
            )
            if numeric_blueprint_type_id > 0 and not get_blueprint_product_row(
                numeric_blueprint_type_id
            ):
                normalized_blueprint_type_id = get_blueprint_for_product(
                    numeric_type_id or numeric_blueprint_type_id
                )
                if normalized_blueprint_type_id:
                    numeric_blueprint_type_id = int(normalized_blueprint_type_id)
            if numeric_blueprint_type_id <= 0:
                return

            current_seen = set(seen or set())
            if numeric_blueprint_type_id in current_seen:
                return
            current_seen.add(numeric_blueprint_type_id)
            blueprint_type_ids.add(numeric_blueprint_type_id)

            product_row = get_blueprint_product_row(numeric_blueprint_type_id) or {}
            resolved_product_type_id = int(
                numeric_type_id or product_row.get("product_type_id") or 0
            )
            _remember_project_blueprint_for_product(
                product_blueprint_cache,
                resolved_product_type_id,
                numeric_blueprint_type_id,
            )

            for (
                material_type_id,
                _material_name,
                _base_quantity,
            ) in get_blueprint_material_rows(numeric_blueprint_type_id):
                child_blueprint_type_id = get_blueprint_for_product(material_type_id)
                collect_output_blueprints(
                    type_id=material_type_id,
                    blueprint_type_id=child_blueprint_type_id,
                    seen=current_seen,
                )

        for item in selected_items:
            collect_output_blueprints(
                type_id=item.type_id,
                blueprint_type_id=item.blueprint_type_id,
            )

        return blueprint_type_ids

    blueprint_inventory_started_at = perf_counter()
    owned_blueprint_inventory_map = _resolve_user_blueprint_inventory(
        user=project.user,
        blueprint_type_ids=collect_project_blueprint_type_ids(),
    )
    record_timing_step(
        "blueprint-inventory",
        "Resolve owned blueprint inventory",
        blueprint_inventory_started_at,
    )

    def build_project_output_node(
        *,
        type_id: int | None,
        type_name: str,
        quantity_needed: int,
        blueprint_type_id: int | None,
        source_item: ProductionProjectItem,
        seen: set[int] | None = None,
    ) -> dict[str, object]:
        numeric_quantity = max(1, int(quantity_needed or 1))
        numeric_type_id = int(type_id or 0) if type_id else None
        numeric_blueprint_type_id = (
            int(blueprint_type_id or 0) if blueprint_type_id else 0
        )
        if numeric_blueprint_type_id > 0 and not get_blueprint_product_row(
            numeric_blueprint_type_id
        ):
            normalized_blueprint_type_id = get_blueprint_for_product(
                numeric_type_id or numeric_blueprint_type_id
            )
            if normalized_blueprint_type_id:
                numeric_blueprint_type_id = int(normalized_blueprint_type_id)
        market_group = get_market_group_info(numeric_type_id or 0)

        if not numeric_blueprint_type_id:
            return {
                "type_id": numeric_type_id,
                "type_name": type_name,
                "quantity": numeric_quantity,
                "cycles": None,
                "produced_per_cycle": None,
                "total_produced": None,
                "surplus": None,
                "market_group": market_group["group_name"],
                "market_group_id": market_group["group_id"],
                "project_inclusion_mode": source_item.inclusion_mode,
                "sub_materials": [],
            }
        current_seen = set(seen or set())
        if numeric_blueprint_type_id in current_seen:
            logger.warning(
                "Stopping recursive craft project expansion for blueprint %s to avoid cycle.",
                numeric_blueprint_type_id,
            )
            return {
                "type_id": numeric_type_id,
                "type_name": type_name,
                "quantity": numeric_quantity,
                "cycles": 0,
                "produced_per_cycle": 0,
                "total_produced": 0,
                "surplus": 0,
                "market_group": market_group["group_name"],
                "market_group_id": market_group["group_id"],
                "project_inclusion_mode": source_item.inclusion_mode,
                "sub_materials": [],
            }

        current_seen.add(numeric_blueprint_type_id)
        product_row = get_blueprint_product_row(numeric_blueprint_type_id) or {}
        resolved_product_type_id = int(
            numeric_type_id or product_row.get("product_type_id") or 0
        )
        resolved_product_type_name = str(
            product_row.get("product_type_name") or type_name or ""
        )
        _remember_project_blueprint_for_product(
            product_blueprint_cache,
            resolved_product_type_id,
            numeric_blueprint_type_id,
        )
        produced_per_cycle = max(1, int(product_row.get("produced_per_cycle") or 1))
        cycles = max(1, ceil(numeric_quantity / produced_per_cycle))
        total_produced = cycles * produced_per_cycle
        surplus = max(0, total_produced - numeric_quantity)
        blueprint_efficiency = get_effective_blueprint_efficiency(
            numeric_blueprint_type_id
        )
        blueprint_me = int(blueprint_efficiency.get("me") or 0)

        recipe_map.setdefault(
            int(numeric_type_id or product_row.get("product_type_id") or 0),
            build_recipe_entry(numeric_blueprint_type_id, blueprint_me),
        )

        children: list[dict[str, object]] = []
        material_rows = get_blueprint_material_rows(numeric_blueprint_type_id)
        for material_type_id, material_name, base_quantity in material_rows:
            material_type_id = int(material_type_id)
            apply_material_efficiency = material_efficiency_applies(
                numeric_blueprint_type_id,
                material_type_id,
            )
            child_quantity = compute_job_material_quantity(
                base_quantity,
                cycles,
                blueprint_me,
                apply_material_efficiency=apply_material_efficiency,
            )
            child_blueprint_type_id = get_blueprint_for_product(material_type_id)
            child_item = source_item
            child_node = build_project_output_node(
                type_id=material_type_id,
                type_name=str(
                    material_name
                    or type_name_cache.get(material_type_id)
                    or material_type_id
                ),
                quantity_needed=child_quantity,
                blueprint_type_id=child_blueprint_type_id,
                source_item=child_item,
                seen=current_seen,
            )
            child_node["material_bonus_applicable"] = apply_material_efficiency
            children.append(child_node)

        return {
            "type_id": resolved_product_type_id,
            "type_name": (
                resolved_product_type_name if not numeric_type_id else type_name
            ),
            "quantity": numeric_quantity,
            "cycles": cycles,
            "produced_per_cycle": produced_per_cycle,
            "total_produced": total_produced,
            "surplus": surplus,
            "blueprint_type_id": numeric_blueprint_type_id,
            "market_group": market_group["group_name"]
            or str(product_row.get("group_name") or ""),
            "market_group_id": (
                market_group["group_id"]
                if market_group["group_id"] is not None
                else product_row.get("group_id")
            ),
            "project_inclusion_mode": source_item.inclusion_mode,
            "sub_materials": children,
        }

    root_nodes_started_at = perf_counter()
    root_nodes = [
        build_project_output_node(
            type_id=item.type_id,
            type_name=item.type_name,
            quantity_needed=item.quantity_requested,
            blueprint_type_id=item.blueprint_type_id,
            source_item=item,
        )
        for item in selected_items
    ]
    record_timing_step("materials-tree", "Build materials tree", root_nodes_started_at)

    cycle_summary: dict[int, dict[str, object]] = {}
    all_type_ids: set[int] = set()

    def register_node(node: dict[str, object]) -> None:
        type_id = int(node.get("type_id") or 0) if node.get("type_id") else 0
        if type_id > 0:
            all_type_ids.add(type_id)
        blueprint_type_id = int(node.get("blueprint_type_id") or 0)
        if blueprint_type_id > 0:
            type_name = str(node.get("type_name") or type_name_cache.get(type_id) or "")
            group_name = str(node.get("market_group") or "")
            entry = cycle_summary.setdefault(
                type_id,
                {
                    "type_id": type_id,
                    "type_name": type_name,
                    "market_group": group_name,
                    "total_needed": 0,
                    "produced_per_cycle": max(
                        1, int(node.get("produced_per_cycle") or 1)
                    ),
                },
            )
            entry["total_needed"] = int(entry.get("total_needed") or 0) + int(
                node.get("quantity") or 0
            )
        for child in node.get("sub_materials", []):
            register_node(child)

    cycle_summary_started_at = perf_counter()
    for node in root_nodes:
        register_node(node)

    for type_id, entry in cycle_summary.items():
        produced_per_cycle = max(1, int(entry.get("produced_per_cycle") or 1))
        total_needed = max(0, int(entry.get("total_needed") or 0))
        cycles = ceil(total_needed / produced_per_cycle) if total_needed > 0 else 0
        total_produced = produced_per_cycle * cycles
        entry["cycles"] = cycles
        entry["total_produced"] = total_produced
        entry["surplus"] = max(0, total_produced - total_needed)
    record_timing_step(
        "cycle-summary", "Aggregate production cycles", cycle_summary_started_at
    )

    market_groups_started_at = perf_counter()
    market_group_map = _resolve_market_groups(all_type_ids)
    for type_id, entry in cycle_summary.items():
        if not entry.get("market_group"):
            info = (
                market_group_map.get(type_id)
                or market_group_map.get(str(type_id))
                or {}
            )
            entry["market_group"] = info.get("group_name") or ""
    record_timing_step(
        "market-groups", "Resolve market groups", market_groups_started_at
    )

    missing_blueprint_name_ids = sorted(
        {
            int(blueprint_type_id)
            for blueprint_type_id in product_blueprint_cache.values()
            if int(blueprint_type_id or 0) > 0
            and int(blueprint_type_id) not in type_name_cache
        }
    )
    if missing_blueprint_name_ids:
        missing_blueprint_names_started_at = perf_counter()
        type_name_cache.update(_resolve_type_names(missing_blueprint_name_ids))
        record_timing_step(
            "blueprint-names",
            "Resolve missing blueprint names",
            missing_blueprint_names_started_at,
        )

    production_time_started_at = perf_counter()
    production_time_map = build_craft_time_map(
        recipe_map=recipe_map,
        product_type_id=None,
        product_type_name="",
        product_output_per_cycle=0,
        root_blueprint_type_id=None,
    )
    record_timing_step(
        "production-times", "Build production time map", production_time_started_at
    )

    character_advisor_started_at = perf_counter()
    craft_character_advisor = build_craft_character_advisor(
        user=project.user,
        production_time_map=production_time_map,
        skill_cache_ttl=skill_cache_ttl,
    )
    record_timing_step(
        "character-advisor", "Build character advisor", character_advisor_started_at
    )

    structure_planner_started_at = perf_counter()
    structure_planner = build_craft_structure_planner(
        product_type_id=None,
        product_type_name="",
        product_output_per_cycle=0,
        craft_cycles_summary=cycle_summary,
        include_all_options=include_full_structure_options,
    )
    record_timing_step(
        "structure-planner", "Build structure planner", structure_planner_started_at
    )

    blueprint_configs_started_at = perf_counter()
    blueprint_configs, blueprint_configs_grouped = (
        _build_project_blueprint_configs_grouped(
            user=project.user,
            cycle_summary=cycle_summary,
            product_blueprint_cache=product_blueprint_cache,
            overrides=overrides,
            type_name_cache=type_name_cache,
            market_group_map=market_group_map,
            user_bp_map=owned_blueprint_inventory_map,
        )
    )
    record_timing_step(
        "blueprint-configs", "Build blueprint configs", blueprint_configs_started_at
    )

    final_outputs = []
    for item, root_node in zip(selected_items, root_nodes):
        resolved_type_id = int(root_node.get("type_id") or item.type_id or 0) or None
        resolved_type_name = str(root_node.get("type_name") or item.type_name or "")
        final_outputs.append(
            {
                "type_id": resolved_type_id,
                "type_name": resolved_type_name,
                "quantity": item.quantity_requested,
                "is_craftable": item.is_craftable,
                "blueprint_type_id": item.blueprint_type_id,
                "inclusion_mode": item.inclusion_mode,
                "category_key": item.category_key,
                "category_label": item.category_label,
            }
        )

    main_blueprint_info = {}
    root_blueprint_type_id = 0
    root_product_type_id = 0
    root_product_output_per_cycle = 0
    root_final_product_qty = 0
    num_runs = max(1, int(workspace_state.get("runs") or 1))
    main_me = 0
    main_te = 0
    direct_materials = []
    materials_by_group = {}

    if len(selected_items) == 1 and root_nodes:
        root_item = selected_items[0]
        root_node = root_nodes[0]
        root_blueprint_type_id = int(
            root_node.get("blueprint_type_id")
            or root_item.blueprint_type_id
            or workspace_state.get("blueprint_type_id")
            or 0
        )
        root_product_type_id = int(root_node.get("type_id") or root_item.type_id or 0)
        root_product_output_per_cycle = max(
            0,
            int(
                root_node.get("produced_per_cycle")
                or _get_blueprint_output_quantity(root_blueprint_type_id)
                or 0
            ),
        )
        root_final_product_qty = max(
            0,
            int(root_item.quantity_requested or root_node.get("quantity") or 0),
        )

        root_efficiency = get_effective_blueprint_efficiency(root_blueprint_type_id)
        main_me = int(root_efficiency.get("me") or 0)
        main_te = int(root_efficiency.get("te") or 0)

        root_children = (
            root_node.get("sub_materials")
            if isinstance(root_node.get("sub_materials"), list)
            else []
        )
        direct_materials = [
            {
                "type_id": int(child.get("type_id") or 0),
                "type_name": str(child.get("type_name") or ""),
                "quantity": max(0, int(child.get("quantity") or 0)),
            }
            for child in root_children
            if int(child.get("type_id") or 0) > 0
        ]
        for material in direct_materials:
            material_type_id = int(material["type_id"])
            group_info = (
                market_group_map.get(material_type_id)
                or market_group_map.get(str(material_type_id))
                or {}
            )
            group_id = group_info.get("group_id")
            group_name = str(group_info.get("group_name") or "Other materials")
            group_key = str(group_id if group_id is not None else group_name)
            group_entry = materials_by_group.setdefault(
                group_key,
                {
                    "group_id": group_id,
                    "group_name": group_name,
                    "items": [],
                },
            )
            group_entry["items"].append(material)

        matching_blueprint_config = next(
            (
                blueprint
                for blueprint in blueprint_configs
                if int(blueprint.get("type_id") or 0) == root_blueprint_type_id
            ),
            None,
        )
        if matching_blueprint_config:
            main_blueprint_info = {
                "type_id": root_blueprint_type_id,
                "product_type_id": int(
                    matching_blueprint_config.get("product_type_id")
                    or root_product_type_id
                    or 0
                ),
                "material_efficiency": int(
                    matching_blueprint_config.get("material_efficiency") or main_me or 0
                ),
                "time_efficiency": int(
                    matching_blueprint_config.get("time_efficiency") or main_te or 0
                ),
                "user_material_efficiency": matching_blueprint_config.get(
                    "user_material_efficiency"
                ),
                "user_time_efficiency": matching_blueprint_config.get(
                    "user_time_efficiency"
                ),
                "is_owned": bool(matching_blueprint_config.get("user_owns", False)),
                "user_owns": bool(matching_blueprint_config.get("user_owns", False)),
                "is_copy": bool(matching_blueprint_config.get("is_copy", False)),
                "runs_available": matching_blueprint_config.get("runs_available"),
            }

    return {
        "type_id": root_blueprint_type_id,
        "bp_type_id": root_blueprint_type_id,
        "project_id": project.id,
        "project_ref": project.project_ref,
        "name": project.name,
        "project_status": project.status,
        "source_kind": project.source_kind,
        "workspace_state": workspace_state,
        "product_type_id": root_product_type_id or None,
        "output_qty_per_run": root_product_output_per_cycle,
        "product_output_per_cycle": root_product_output_per_cycle,
        "final_product_qty": root_final_product_qty,
        "num_runs": num_runs,
        "me": main_me,
        "te": main_te,
        "materials_tree": root_nodes,
        "materials": direct_materials,
        "direct_materials": direct_materials,
        "materials_by_group": materials_by_group,
        "market_group_map": market_group_map,
        "recipe_map": recipe_map,
        "craft_cycles_summary": cycle_summary,
        "blueprint_configs_grouped": blueprint_configs_grouped,
        "production_time_map": production_time_map,
        "craft_character_advisor": craft_character_advisor,
        "structure_planner": structure_planner,
        "final_outputs": final_outputs,
        "page": {
            "blueprint_configs": [
                {
                    "type_id": blueprint.get("type_id"),
                    "product_type_id": blueprint.get("product_type_id"),
                    "material_efficiency": blueprint.get("material_efficiency", 0),
                    "time_efficiency": blueprint.get("time_efficiency", 0),
                    "user_material_efficiency": blueprint.get(
                        "user_material_efficiency"
                    ),
                    "user_time_efficiency": blueprint.get("user_time_efficiency"),
                    "is_owned": blueprint.get("user_owns", False),
                    "user_owns": blueprint.get("user_owns", False),
                    "is_copy": blueprint.get("is_copy", False),
                    "runs_available": blueprint.get("runs_available"),
                    "shared_copies_available": bool(
                        blueprint.get("shared_copies_available", [])
                    ),
                }
                for blueprint in blueprint_configs
            ],
            "craft_cycles_summary_static": {
                str(type_id): {
                    "type_id": entry.get("type_id"),
                    "type_name": entry.get("type_name"),
                    "cycles": entry.get("cycles", 0),
                    "total_needed": entry.get("total_needed", 0),
                    "produced_per_cycle": entry.get("produced_per_cycle", 0),
                    "total_produced": entry.get("total_produced", 0),
                    "surplus": entry.get("surplus", 0),
                }
                for type_id, entry in cycle_summary.items()
            },
            "main_bp_info": main_blueprint_info,
            "workspace_timing": build_workspace_timing(),
        },
    }


def _parse_eft_project_import(raw_text: str) -> dict[str, object]:
    lines = [line.rstrip() for line in raw_text.split("\n")]
    first_non_empty_index = next(
        (index for index, line in enumerate(lines) if line.strip()), None
    )
    if first_non_empty_index is None:
        return {"source_kind": "eft", "source_name": "", "entries": []}

    header_line = lines[first_non_empty_index].strip()
    header_match = EFT_HEADER_RE.match(header_line)
    if not header_match:
        return _parse_manual_project_import(raw_text)

    entries: list[dict[str, object]] = [
        _build_entry(
            type_name=header_match.group("hull").strip(),
            quantity=1,
            category=HULL_CATEGORY,
            source_line=header_line,
        )
    ]

    grouped_lines = _split_non_empty_groups(lines[first_non_empty_index + 1 :])
    for group_index, group_lines in enumerate(grouped_lines):
        category = _get_eft_category(group_index)
        for raw_line in group_lines:
            parsed_line = _parse_line_item(raw_line)
            if not parsed_line:
                continue
            entries.append(
                _build_entry(
                    type_name=parsed_line["type_name"],
                    quantity=parsed_line["quantity"],
                    category=category,
                    source_line=raw_line,
                )
            )

    hull_name = header_match.group("hull").strip()
    fit_name = header_match.group("fit_name").strip()
    if hull_name and fit_name:
        source_name = f"{hull_name} // {fit_name}"
    else:
        source_name = fit_name or hull_name

    return {
        "source_kind": "eft",
        "source_name": source_name,
        "entries": entries,
    }


def _parse_manual_project_import(raw_text: str) -> dict[str, object]:
    entries: list[dict[str, object]] = []
    for raw_line in raw_text.splitlines():
        parsed_line = _parse_line_item(raw_line)
        if not parsed_line:
            continue
        entries.append(
            _build_entry(
                type_name=parsed_line["type_name"],
                quantity=parsed_line["quantity"],
                category=MANUAL_CATEGORY,
                source_line=raw_line,
            )
        )

    return {
        "source_kind": "manual",
        "source_name": "",
        "entries": entries,
    }


def _group_project_entries(
    entries: Sequence[dict[str, object]],
) -> list[dict[str, object]]:
    grouped: OrderedDict[str, dict[str, object]] = OrderedDict()
    for entry in sorted(
        entries,
        key=lambda row: (
            _coerce_category_order(row.get("category_order")),
            str(row.get("category_label") or ""),
            str(row.get("type_name") or ""),
        ),
    ):
        category_key = str(entry.get("category_key") or "other")
        category_label = str(entry.get("category_label") or "Other")
        if category_key not in grouped:
            grouped[category_key] = {
                "key": category_key,
                "label": category_label,
                "order": _coerce_category_order(entry.get("category_order")),
                "items": [],
            }
        grouped[category_key]["items"].append(entry)
    return list(grouped.values())


def _resolve_item_types_by_name(names: Sequence[str]) -> dict[str, dict[str, object]]:
    if not names:
        return {}

    placeholders = ", ".join(["%s"] * len(names))
    lower_names = [name.casefold() for name in names]
    query = f"""
                SELECT t.id, t.name, COALESCE(g.name, '')
        FROM eve_sde_itemtype t
        LEFT JOIN eve_sde_itemgroup g ON t.group_id = g.id
                WHERE LOWER(t.name) IN ({placeholders})
                    AND COALESCE(t.published, 0) = 1
    """

    resolved: dict[str, dict[str, object]] = {}
    with connection.cursor() as cursor:
        cursor.execute(query, lower_names)
        for type_id, type_name, group_name in cursor.fetchall():
            resolved[str(type_name).casefold()] = {
                "type_id": int(type_id),
                "type_name": str(type_name),
                "group_name": str(group_name or ""),
            }
    return resolved


def _resolve_blueprints_for_products(type_ids: Iterable[int]) -> dict[int, int]:
    type_id_list = [int(type_id) for type_id in type_ids if int(type_id or 0) > 0]
    if not type_id_list:
        return {}

    placeholders = ", ".join(["%s"] * len(type_id_list))
    query = f"""
        SELECT p.product_eve_type_id, p.eve_type_id, p.activity_id
        FROM indy_hub_sdeindustryactivityproduct p
        JOIN eve_sde_itemtype blueprint_t ON blueprint_t.id = p.eve_type_id
        JOIN eve_sde_itemtype product_t ON product_t.id = p.product_eve_type_id
        WHERE p.activity_id IN (1, 11)
                AND p.product_eve_type_id IN ({placeholders})
                AND COALESCE(blueprint_t.published, 0) = 1
                AND COALESCE(product_t.published, 0) = 1
        ORDER BY
            p.product_eve_type_id,
            CASE p.activity_id WHEN 1 THEN 0 WHEN 11 THEN 1 ELSE 99 END,
            p.eve_type_id
    """

    blueprint_map: dict[int, int] = {}
    with connection.cursor() as cursor:
        cursor.execute(query, type_id_list)
        for product_type_id, blueprint_type_id, _activity_id in cursor.fetchall():
            if product_type_id is None or blueprint_type_id is None:
                continue
            numeric_product_type_id = int(product_type_id)
            if numeric_product_type_id in blueprint_map:
                continue
            blueprint_map[numeric_product_type_id] = int(blueprint_type_id)
    return blueprint_map


def _split_non_empty_groups(lines: Sequence[str]) -> list[list[str]]:
    groups: list[list[str]] = []
    current_group: list[str] = []
    for raw_line in lines:
        line = raw_line.strip()
        if not line:
            if current_group:
                groups.append(current_group)
                current_group = []
            continue
        current_group.append(line)
    if current_group:
        groups.append(current_group)
    return groups


def _parse_line_item(raw_line: str) -> dict[str, object] | None:
    line = str(raw_line or "").strip()
    if not line:
        return None

    suffix_match = QUANTITY_SUFFIX_RE.match(line)
    if suffix_match:
        return {
            "type_name": suffix_match.group("name").strip(),
            "quantity": max(1, int(suffix_match.group("quantity"))),
        }

    prefix_match = QUANTITY_PREFIX_RE.match(line)
    if prefix_match:
        return {
            "type_name": prefix_match.group("name").strip(),
            "quantity": max(1, int(prefix_match.group("quantity"))),
        }

    return {"type_name": line, "quantity": 1}


def _build_entry(
    *,
    type_name: str,
    quantity: int,
    category: dict[str, object],
    source_line: str,
) -> dict[str, object]:
    return {
        "type_name": str(type_name).strip(),
        "quantity": max(1, int(quantity or 1)),
        "category_key": str(category["key"]),
        "category_label": str(category["label"]),
        "category_order": int(category["order"]),
        "source_line": str(source_line).strip(),
    }


def _get_eft_category(group_index: int) -> dict[str, object]:
    if group_index < len(EFT_CATEGORY_SPECS):
        return EFT_CATEGORY_SPECS[group_index]
    return {
        "key": f"eft_group_{group_index}",
        "label": f"Group {group_index + 1}",
        "order": 100 + group_index,
    }


def _normalize_resolved_eft_category(
    entry: dict[str, object],
    group_name: str,
) -> dict[str, object] | None:
    category_key = str(entry.get("category_key") or "")
    if category_key not in {"subsystems", "drone_bay"}:
        return None

    normalized_group_name = str(group_name or "").casefold()
    type_name = str(entry.get("type_name") or "")
    source_line = str(entry.get("source_line") or "")
    is_drone_group = any(
        keyword in normalized_group_name for keyword in DRONE_GROUP_KEYWORDS
    )
    is_subsystem_group = any(
        keyword in normalized_group_name for keyword in SUBSYSTEM_GROUP_KEYWORDS
    )
    if not is_subsystem_group and _looks_like_strategic_cruiser_subsystem(
        type_name=type_name,
        source_line=source_line,
    ):
        is_subsystem_group = True

    if category_key == "subsystems":
        if is_drone_group:
            return EFT_CATEGORY_SPEC_BY_KEY["drone_bay"]
        if not is_subsystem_group:
            return EFT_CATEGORY_SPEC_BY_KEY["cargo"]
        return None

    if is_subsystem_group:
        return EFT_CATEGORY_SPEC_BY_KEY["subsystems"]
    if not is_drone_group:
        return EFT_CATEGORY_SPEC_BY_KEY["cargo"]
    return None


def _looks_like_strategic_cruiser_subsystem(
    *, type_name: str, source_line: str
) -> bool:
    candidate_texts = [str(type_name or ""), str(source_line or "")]
    return any(
        STRATEGIC_CRUISER_SUBSYSTEM_NAME_RE.search(text)
        for text in candidate_texts
        if text
    )


def _resolve_type_names(type_ids: Iterable[int | None]) -> dict[int, str]:
    numeric_ids = sorted(
        {int(type_id) for type_id in type_ids if int(type_id or 0) > 0}
    )
    if not numeric_ids:
        return {}

    placeholders = ", ".join(["%s"] * len(numeric_ids))
    with connection.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT id, COALESCE(name_en, name)
            FROM eve_sde_itemtype
                        WHERE id IN ({placeholders})
                            AND COALESCE(published, 0) = 1
            """,
            numeric_ids,
        )
        return {
            int(type_id): str(type_name or "")
            for type_id, type_name in cursor.fetchall()
        }


def _resolve_market_groups(type_ids: Iterable[int]) -> dict[int, dict[str, object]]:
    numeric_ids = sorted(
        {int(type_id) for type_id in type_ids if int(type_id or 0) > 0}
    )
    if not numeric_ids:
        return {}

    placeholders = ", ".join(["%s"] * len(numeric_ids))
    with connection.cursor() as cursor:
        cursor.execute(
            f"""
            SELECT t.id, COALESCE(g.name, ''), g.id
            FROM eve_sde_itemtype t
            LEFT JOIN eve_sde_itemgroup g ON t.group_id = g.id
                        WHERE t.id IN ({placeholders})
                            AND COALESCE(t.published, 0) = 1
            """,
            numeric_ids,
        )
        return {
            int(type_id): {
                "group_name": str(group_name or ""),
                "group_id": int(group_id) if group_id is not None else None,
            }
            for type_id, group_name, group_id in cursor.fetchall()
        }


def _resolve_user_blueprint_inventory(
    *,
    user,
    blueprint_type_ids: Iterable[int | None],
) -> dict[int, dict[str, object]]:
    numeric_ids = sorted(
        {int(type_id) for type_id in blueprint_type_ids if int(type_id or 0) > 0}
    )
    if not numeric_ids:
        return {}

    user_blueprints = (
        Blueprint.objects.filter(
            owner_user=user,
            owner_kind=Blueprint.OwnerKind.CHARACTER,
            type_id__in=numeric_ids,
        )
        .values_list(
            "type_id",
            "material_efficiency",
            "time_efficiency",
            "bp_type",
            "runs",
        )
        .order_by("type_id", "-material_efficiency", "-time_efficiency")
    )

    user_bp_map: dict[int, dict[str, object]] = {}
    for bp_type_id, bp_me, bp_te, bp_type, runs in user_blueprints:
        entry = user_bp_map.setdefault(
            int(bp_type_id),
            {
                "original": None,
                "best_copy": None,
                "copy_runs_total": 0,
            },
        )

        if bp_type == Blueprint.BPType.ORIGINAL:
            if not entry["original"]:
                entry["original"] = {"me": int(bp_me or 0), "te": int(bp_te or 0)}
            else:
                current = entry["original"]
                if bp_me > current["me"] or (
                    bp_me == current["me"] and bp_te > current["te"]
                ):
                    entry["original"] = {"me": int(bp_me or 0), "te": int(bp_te or 0)}
        else:
            entry["copy_runs_total"] = int(entry.get("copy_runs_total") or 0) + int(
                runs or 0
            )
            if not entry["best_copy"]:
                entry["best_copy"] = {"me": int(bp_me or 0), "te": int(bp_te or 0)}
            else:
                current = entry["best_copy"]
                if bp_me > current["me"] or (
                    bp_me == current["me"] and bp_te > current["te"]
                ):
                    entry["best_copy"] = {"me": int(bp_me or 0), "te": int(bp_te or 0)}

    return user_bp_map


def _build_project_blueprint_configs_grouped(
    *,
    user,
    cycle_summary: dict[int, dict[str, object]],
    product_blueprint_cache: dict[int, int | None],
    overrides: dict[int, dict[str, int]],
    type_name_cache: dict[int, str],
    market_group_map: dict[int, dict[str, object]] | None = None,
    user_bp_map: dict[int, dict[str, object]] | None = None,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    market_group_map = market_group_map or {}
    if user_bp_map is None:
        user_bp_map = _resolve_user_blueprint_inventory(
            user=user,
            blueprint_type_ids=product_blueprint_cache.values(),
        )
    blueprints = []
    for type_id, entry in sorted(
        cycle_summary.items(),
        key=lambda item: str(item[1].get("type_name") or ""),
    ):
        blueprint_type_id = product_blueprint_cache.get(int(type_id))
        if not blueprint_type_id:
            continue
        is_reaction = bool(is_reaction_blueprint(int(blueprint_type_id)))
        override = overrides.get(int(blueprint_type_id), {})
        user_entry = user_bp_map.get(int(blueprint_type_id), {})
        selected_owned_entry, selected_is_copy = _select_best_owned_blueprint_entry(
            user_entry
        )
        user_owns = bool(selected_owned_entry)
        is_copy = bool(selected_is_copy)
        runs_available = (
            int(user_entry.get("copy_runs_total") or 0) if is_copy else None
        )
        user_material_efficiency = (
            int(selected_owned_entry.get("me") or 0) if selected_owned_entry else None
        )
        user_time_efficiency = (
            int(selected_owned_entry.get("te") or 0) if selected_owned_entry else None
        )
        # Reaction "blueprints" (Reaction Formulas) cannot have non-zero ME/TE
        # and cannot be copied: force ME/TE to 0 (template hides the inputs)
        # and clear runs/shared copies so the card never enters the orange
        # "shared copies available" branch. They still belong in the tab so
        # players can see which formulas the project consumes (issue #69).
        if is_reaction:
            default_me = 0
            default_te = 0
            shared_copies: list[dict[str, object]] = []
            runs_available = None
            # Reactions cannot be copied in EVE: any owned reaction formula is
            # by definition an original, so never flag the card as "copy
            # owned" (the template would otherwise display a misleading
            # "COPY OWNED" badge).
            is_copy = False
        else:
            default_me = (
                user_material_efficiency if user_material_efficiency is not None else 0
            )
            default_te = user_time_efficiency if user_time_efficiency is not None else 0
            shared_copies = []
        market_group_info = market_group_map.get(int(type_id)) or {}
        category_name = str(market_group_info.get("group_name") or "").strip()
        blueprints.append(
            {
                "type_id": int(blueprint_type_id),
                "type_name": type_name_cache.get(int(blueprint_type_id))
                or f"Blueprint {blueprint_type_id}",
                "material_efficiency": (
                    int(override["me"])
                    if "me" in override and not is_reaction
                    else default_me
                ),
                "time_efficiency": (
                    int(override["te"])
                    if "te" in override and not is_reaction
                    else default_te
                ),
                "user_material_efficiency": user_material_efficiency,
                "user_time_efficiency": user_time_efficiency,
                "user_owns": user_owns,
                "is_copy": is_copy,
                "is_reaction": is_reaction,
                "runs_available": runs_available,
                "shared_copies_available": shared_copies,
                "product_type_id": int(type_id),
                "product_type_name": str(entry.get("type_name") or ""),
                "total_needed": int(entry.get("total_needed") or 0),
                "category_name": category_name,
            }
        )

    if not blueprints:
        return ([], [])

    # Group cards by product category (eve_sde item group) so the Blueprints
    # tab is easier to scan when a project mixes ships, modules, ammo, …
    # Reactions are always rendered last in their own dedicated section since
    # their cards are simpler (no ME/TE / copy controls).
    fallback_group = "Other"
    reactions_group = "Reactions"
    grouped_by_category: dict[str, list[dict[str, object]]] = {}
    for bp in blueprints:
        if bp.get("is_reaction"):
            key = reactions_group
        else:
            key = bp.get("category_name") or fallback_group
        grouped_by_category.setdefault(key, []).append(bp)

    def _group_sort_key(item: tuple[str, list[dict[str, object]]]) -> tuple:
        name, _cards = item
        # Reactions last, then "Other" before reactions, then alphabetical.
        return (
            name == reactions_group,
            name == fallback_group,
            name.casefold(),
        )

    grouped = [
        {
            "group_name": group_name,
            "levels": [{"level": 0, "blueprints": cards}],
        }
        for group_name, cards in sorted(
            grouped_by_category.items(), key=_group_sort_key
        )
    ]

    return (blueprints, grouped)


def _coerce_category_order(value: object) -> int:
    try:
        if value is None:
            return 999
        return int(value)
    except (TypeError, ValueError):
        return 999
